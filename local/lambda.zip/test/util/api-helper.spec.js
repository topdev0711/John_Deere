const apiHelper = require("../../lib/util/api-helper");
const conf = require("../../lib/conf.js");
const request = require('request-promise');
const NodeCache = require( "node-cache" );


jest.mock("../../lib/conf");
jest.mock('request-promise');
jest.genMockFromModule("node-cache");
jest.mock("node-cache");

const mockCache = {
  get: jest.fn(),
  set: jest.fn()
};

NodeCache.mockImplementation((_opts) => mockCache);

const config = {
    region: 'us-east-1',
    dataTypeUrl: 'https://edl-catalog-api.vpn-devl.us.e03.c01.johndeerecloud.com/v1/types',
    postPolicyUrl: 'https://edl-entitlements-api.vpn-devl.us.e03.c01.johndeerecloud.com/v1/policies',
    edlOAuthUrl: 'https://johndeere.oktapreview.com/oauth2/ausazr82rqSWEnxwI0h7/v1/token',
    edlOauthClientId: 'fake-client-id',
    edlOauthClientSecret: 'decrypted'
};

describe('API Helper', () => {

    beforeEach(() => {
        conf.getConfig.mockResolvedValue(config);
        apiHelper.resetCache();
        apiHelper.overrideCache(mockCache);
    });

    describe('cache tests', () => {
      it('should get jwt from cache if available', async () => {
        const localCache = {
          get: jest.fn((_key) => {return 'fake-token'}),
          set: jest.fn()
        };
        apiHelper.resetCache();
        apiHelper.overrideCache(localCache);

        process.env.environment = 'devl';
        const expectedResponse = JSON.stringify({hello: 'world'});
        request.mockResolvedValue(expectedResponse);
        //when
        await apiHelper.get('fake-get-url');
        //then
        expect(request).toHaveBeenCalledTimes(1);
        expect(localCache.get).toBeCalledTimes(1);
        expect(localCache.get).toBeCalledWith('jwt');
        expect(request.mock.calls[0][0]).toEqual({uri: 'fake-get-url', 'headers': {'Authorization': 'Bearer fake-token'}, 'method':'GET'});
      });

      it('should set jwt in cache if none are available', async () => {
        const localCache = {
          get: jest.fn(),
          set: jest.fn()
        };
        apiHelper.resetCache();
        apiHelper.overrideCache(localCache);

        const body = {'grant_type': 'client_credentials' ,'client_id': 'fake-client-id', 'client_secret': 'decrypted'};
        const headers = {'Content-Type': 'application/x-www-form-urlencoded'};
        const expectedTokenResponse = JSON.stringify({access_token: 'fake-access-token'});
        process.env.environment = 'devl';
        const expectedResponse = JSON.stringify({hello: 'world'});
        request
        .mockResolvedValueOnce(expectedTokenResponse)
        .mockResolvedValueOnce(expectedResponse);
        //when
        await apiHelper.get('fake-get-url');
        //then
        expect(request).toHaveBeenCalledTimes(2);
        expect(localCache.get).toBeCalledTimes(1);
        expect(localCache.get).toBeCalledWith('jwt');
        expect(localCache.set).toBeCalledTimes(1);
        expect(localCache.set).toBeCalledWith('jwt', 'fake-access-token');
        expect(request.mock.calls[0][0]).toEqual({uri: 'https://johndeere.oktapreview.com/oauth2/ausazr82rqSWEnxwI0h7/v1/token', 'method':'POST', headers, form: body});
        expect(request.mock.calls[1][0]).toEqual({uri: 'fake-get-url', 'headers': {'Authorization': 'Bearer fake-access-token'}, 'method':'GET'});
      });
    });

    it('Should call get based on Notification URL', async() => {
        //given
        const body = {'grant_type': 'client_credentials' ,'client_id': 'fake-client-id', 'client_secret': 'decrypted'};
        const headers = {'Content-Type': 'application/x-www-form-urlencoded'};
        process.env.environment = 'devl';
        const expectedTokenResponse = JSON.stringify({access_token: 'fake-access-token'});
        const expectedResponse = JSON.stringify({hello: 'world'});
        request.mockResolvedValue(expectedResponse);
        request
             .mockResolvedValueOnce(expectedTokenResponse)
             .mockResolvedValueOnce(expectedResponse);
        //when
        await apiHelper.get('fake-get-url');
        //then
        expect(request).toHaveBeenCalledTimes(2);
        expect(mockCache.get).toBeCalledWith('jwt');
        expect(request.mock.calls[0][0]).toEqual({uri: 'https://johndeere.oktapreview.com/oauth2/ausazr82rqSWEnxwI0h7/v1/token', 'method':'POST', headers, form: body});
        expect(request.mock.calls[1][0]).toEqual({uri: 'fake-get-url', 'headers': {'Authorization': 'Bearer fake-access-token'}, 'method':'GET'});
    });

    it('Should call approve based on Notification URL', async() => {
         //given
         const body = {'grant_type': 'client_credentials' ,'client_id': 'fake-client-id', 'client_secret': 'decrypted'};
         const headers = {'Content-Type': 'application/x-www-form-urlencoded'};
         process.env.environment = 'devl';
         const expectedTokenResponse = JSON.stringify({access_token: 'fake-access-token'});
         const expectedResponse = JSON.stringify({status: '200'});
         const anyNotification = {details: [{any: 'notification'}]};
         request.mockResolvedValue(expectedResponse);
         request
              .mockResolvedValueOnce(expectedTokenResponse)
              .mockResolvedValueOnce(expectedResponse);
        //when
        await apiHelper.approve('fake-approve-url', anyNotification); // Approve Should have Details for Dataset.
        //then
        expect(request).toHaveBeenCalledTimes(2);
        expect(request.mock.calls[0][0]).toEqual({uri: 'https://johndeere.oktapreview.com/oauth2/ausazr82rqSWEnxwI0h7/v1/token', 'method':'POST', headers, form: body});
        expect(request.mock.calls[1][0]).toEqual({uri: 'fake-approve-url/approve', 'headers': {'Authorization': 'Bearer fake-access-token'}, 'method':'POST', body: anyNotification, 'json': true});
    });

    it('Should call reject based on Notification URL', async() => {
        //given
        const body = {'grant_type': 'client_credentials' ,'client_id': 'fake-client-id', 'client_secret': 'decrypted'};
        const headers = {'Content-Type': 'application/x-www-form-urlencoded'};
        process.env.environment = 'devl';
        const expectedTokenResponse = JSON.stringify({access_token: 'fake-access-token'});
        const expectedResponse = JSON.stringify({status: '200'});
        request.mockResolvedValue(expectedResponse);
        request
             .mockResolvedValueOnce(expectedTokenResponse)
             .mockResolvedValueOnce(expectedResponse);
        //when
        await apiHelper.reject('fake-reject-url', 'System Rejected');
        //then
        expect(request).toHaveBeenCalledTimes(2);
        expect(request.mock.calls[0][0]).toEqual({uri: 'https://johndeere.oktapreview.com/oauth2/ausazr82rqSWEnxwI0h7/v1/token', 'method':'POST', headers, form: body});
        expect(request.mock.calls[1][0]).toEqual({uri: 'fake-reject-url/reject', body: {reason: 'System Rejected'}, 'headers': {'Authorization': 'Bearer fake-access-token'}, 'method':'POST', 'json': true});
    });

    it('Should call Save to EDL based on Notification URL', async() => {
        //when
        const body = {'grant_type': 'client_credentials' ,'client_id': 'fake-client-id', 'client_secret': 'decrypted'};
        const headers = {'Content-Type': 'application/x-www-form-urlencoded'};
        process.env.environment = 'devl';
        const expectedResponse = JSON.stringify({access_token: 'fake-access-token'});
        request.mockResolvedValue(expectedResponse);
        await apiHelper.saveToEdl('fake-edl-url', 'EDL Param');
        //then
        expect(request).toHaveBeenCalledTimes(2);
        expect(request).toBeCalledWith({uri: 'https://johndeere.oktapreview.com/oauth2/ausazr82rqSWEnxwI0h7/v1/token', 'method':'POST', headers, form: body});
        expect(request.mock.calls[1][0]).toEqual({uri: 'fake-edl-url', 'method': 'POST', 'headers': {'Authorization': 'Bearer fake-access-token','Content-type': 'application/json'},'body': "\"EDL Param\""});
    });

    it('Should call Delete from EDL based on datatype name', async () => {
      //given
      const body = {'grant_type': 'client_credentials' ,'client_id': 'fake-client-id', 'client_secret': 'decrypted'};
      const headers = {'Content-Type': 'application/x-www-form-urlencoded'};
      process.env.environment = 'devl';
      const expectedTokenResponse = JSON.stringify({access_token: 'fake-access-token'});
      const expectedResponse = JSON.stringify({requestId: 'some request id'});
      const dataTypeName = 'datatype name';
      request
        .mockResolvedValueOnce(expectedTokenResponse)
        .mockResolvedValueOnce(expectedResponse);

      //when
      await apiHelper.deleteFromEdl(dataTypeName);

      //then
      expect(request).toHaveBeenCalledTimes(2);
      expect(request).toBeCalledWith({uri: 'https://johndeere.oktapreview.com/oauth2/ausazr82rqSWEnxwI0h7/v1/token', 'method':'POST', headers, form: body});
      expect(request.mock.calls[1][0]).toEqual({uri: `${config.dataTypeUrl}/${dataTypeName}`, 'method': 'DELETE', 'headers': {'Authorization': 'Bearer fake-access-token','Content-type': 'application/json'}});
    });

    it('Should throw and log an error in Delete from EDL if error returned', async () => {
      //given
      process.env.environment = 'devl';
      const expectedTokenResponse = JSON.stringify({access_token: 'fake-access-token'});
      const dataTypeName = 'datatype name';
      const error = 'fake error message';

      request
        .mockResolvedValueOnce(expectedTokenResponse)
        .mockRejectedValueOnce(error);

      //when
      try {
        await apiHelper.deleteFromEdl(dataTypeName);
      } catch(response) {
        expect(response).toEqual(error)
      }
    });

    it('Should throw and log any exception for fetch', async() => {
        //given
        process.env.environment = 'devl';
        const error = 'fake error message';
        request.mockRejectedValue(error);
        //when
        try{
            await apiHelper.saveToEdl('fake-edl-url', 'EDL Param');
        } catch(response) {
            expect(error).toEqual(response);
        }
    });

    it('Should throw and while fetching Okta Token for EDL', () => {
        //given
        process.env.environment = 'devl';
        const error = 'fake error message';
        request.mockRejectedValue(error);

        return expect(apiHelper.get('fake-get-url')).rejects.toEqual(error);
      });

    it('Should get data type from edl', async() => {
        //given
        const body = {'grant_type': 'client_credentials' ,'client_id': 'fake-client-id', 'client_secret': 'decrypted'};
        const headers = {'Content-Type': 'application/x-www-form-urlencoded'};
        process.env.environment = 'devl';
        const expectedTokenResponse = JSON.stringify({access_token: 'fake-access-token'});
        const dataTypeName = 'com.deere.enterprise.datalake.enhance.core.fakedatatype';
        const expectedResponse = JSON.stringify({name: 'com.deere.enterprise.datalake.enhance.core.fakedatatype'});
        request
             .mockResolvedValueOnce(expectedTokenResponse)
             .mockResolvedValueOnce(expectedResponse);
        //when
        await apiHelper.getDataType(dataTypeName);
        //then
        expect(request).toHaveBeenCalledTimes(2);
        expect(request).toBeCalledWith({uri: 'https://johndeere.oktapreview.com/oauth2/ausazr82rqSWEnxwI0h7/v1/token', 'method':'POST', headers, form: body});
        expect(request.mock.calls[1][0]).toEqual({uri: `${config.dataTypeUrl}/${dataTypeName}`, 'method': 'GET', 'headers': {'Authorization': 'Bearer fake-access-token','Accept': 'application/json'}});
    });

    it('Should get EDL Metadata based on Search Term', async() => {
       //given
        const edlMetaDataURL = `${config.dataTypeUrl}`.replace("/types", "/search");
        const searchTerm = {
            "match": {
                "jdCatalogId": "dcd7ea25-5f19-3ac4-99ec-8a5c549533dd@*"
            }
        };
        const edlMetaDataBody = JSON.stringify({
            "index": "types",
            "query": {
                "match": {
                    "jdCatalogId": "dcd7ea25-5f19-3ac4-99ec-8a5c549533dd@*"
                }
            }
        });

        const body = {'grant_type': 'client_credentials' ,'client_id': 'fake-client-id', 'client_secret': 'decrypted'};
        const headers = {'Content-Type': 'application/x-www-form-urlencoded'};
        process.env.environment = 'devl';
        const expectedTokenResponse = JSON.stringify({access_token: 'fake-access-token'});
        const expectedResponse = JSON.stringify([
            {
                _source: {
                    name: "com.deere.enterprise.datalake.raw.cps.pega"
                }
            }
        ]);

        request
            .mockResolvedValueOnce(expectedTokenResponse)
            .mockResolvedValueOnce(expectedResponse);
       //when
        await apiHelper.getEDLMetadata("types", searchTerm);
       //then
        expect(request).toHaveBeenCalledTimes(2);
        expect(request).toBeCalledWith({uri: 'https://johndeere.oktapreview.com/oauth2/ausazr82rqSWEnxwI0h7/v1/token', 'method':'POST', headers, form: body});
        expect(request.mock.calls[1][0]).toEqual({'method': 'POST', uri: edlMetaDataURL, 'headers': {'Authorization': 'Bearer fake-access-token','Accept': 'application/json', 'Content-Type': 'application/json'}, body: edlMetaDataBody});
    });


    it('Should get EDL Metadata based on override query', async() => {
      //given
       const edlMetaDataURL = `${config.dataTypeUrl}`.replace("/types", "/search");
       const override = {
        "index": "schemas3",
        "query": {
          "bool": {
            "filter": [
              {
                "terms": {
                  "_id": ['some-id']
                }
              }
            ]
          }
        },
        "_source": ["jdCatalogId"],
        "size": 10000
      };
       const edlMetaDataBody = JSON.stringify(override);

       const body = {'grant_type': 'client_credentials' ,'client_id': 'fake-client-id', 'client_secret': 'decrypted'};
       const headers = {'Content-Type': 'application/x-www-form-urlencoded'};
       process.env.environment = 'devl';
       const expectedTokenResponse = JSON.stringify({access_token: 'fake-access-token'});
       const expectedResponse = JSON.stringify([
           {
               _source: {
                   name: "com.deere.enterprise.datalake.raw.cps.pega"
               }
           }
       ]);

       request
           .mockResolvedValueOnce(expectedTokenResponse)
           .mockResolvedValueOnce(expectedResponse);
      //when
       await apiHelper.getEDLMetadata("",  "", override);
      //then
       expect(request).toHaveBeenCalledTimes(2);
       expect(request).toBeCalledWith({uri: 'https://johndeere.oktapreview.com/oauth2/ausazr82rqSWEnxwI0h7/v1/token', 'method':'POST', headers, form: body});
       expect(request.mock.calls[1][0]).toEqual({'method': 'POST', uri: edlMetaDataURL, 'headers': {'Authorization': 'Bearer fake-access-token','Accept': 'application/json', 'Content-Type': 'application/json'}, body: edlMetaDataBody});
   });
});
