const edlPolicyService = require("../../lib/services/edl-permissions-service");
const jdCatalogPolicyJson = require("../../test-data/jd-catalog-policy.json");
const edlPolicy = require("../../test-data/edl-policy.json");
const conf = require("../../lib/conf.js");
const apiHelper = require('../../lib/util/api-helper');
const timestamp = require('jest-mock-now')(new Date(1561409595948));

jest.mock("../../lib/conf");
jest.mock('../../lib/util/api-helper');

const config = {
  postPolicyUrl: 'https://edl-entitlements-api.vpn-devl.us.e03.c01.johndeerecloud.com/v1/policies'
};

describe("Policy Service Test Suite", () => {

  beforeEach(async() => {
    jest.spyOn(conf, 'getEnv').mockReturnValue('devl');
    conf.getConfig.mockResolvedValue(config);
    process.env.multi_perm_enabled = 'false';
  });

  it("should handle aggregation of entitlements", async () => {
    process.env.multi_perm_enabled = 'true';
    const expectedEnts = [{
      classification: ['gicp2'],
      community: 'comm2',
      subcommunities: ['subcomm2'],
      countriesrepresented: ['cr2'],
      markers: ['tag2'],
    },{
      classification: ['gicp1'],
      community: 'comm1',
      subcommunities: ['subcomm1'],
      countriesrepresented: ['cr1'],
      markers: ['tag1'],
    }];
    apiHelper.get.mockResolvedValue([
      { entitlements: [createEntitlment(1)],
        updatedAt: "2020-07-02T15:59:27.793Z",
        group:'some-group'},
      { entitlements: [createEntitlment(2)],
        updatedAt: "2020-07-10T18:34:41.973Z",
        group:'AWS-GIT-DWIS-ADMIN'}
    ]);

    const result = await edlPolicyService.createEdlRecord({...jdCatalogPolicyJson});
    const expectedCopy = {...edlPolicy};
    delete expectedCopy.startDate;
    delete result.startDate;
    expect(result).toEqual({...expectedCopy, entitlement: expectedEnts, endDate: null})
  });

  it("should handle aggregation of entitlements when views present", async () => {
    process.env.multi_perm_enabled = 'true';
    const expectedEnts = [{
      classification: ['gicp2'],
      community: 'comm2',
      subcommunities: ['subcomm2'],
      countriesrepresented: ['cr2'],
      markers: ['tag2'],
    },{
      classification: ['gicp1'],
      community: 'comm1',
      subcommunities: ['subcomm1'],
      countriesrepresented: ['cr1'],
      markers: ['tag1'],
    }];
    apiHelper.get.mockResolvedValue([
      { entitlements: [createEntitlment(1)],
        updatedAt: "2020-07-02T15:59:27.793Z",
        group:'some-group'},
      { entitlements: [createEntitlment(2)],
        updatedAt: "2020-07-10T18:34:41.973Z",
        group:'AWS-GIT-DWIS-ADMIN'}
    ]);

    views = [{name: 'view1', status: 'AVAILABLE'}, {name: 'view2', status: 'DELETED'}, {name: 'view1', status: 'AVAILABLE'}, {name: 'view3', status: 'DRIFTED'}];
    expectedViews = ['view1', 'view2', 'view3'];
    jdCatalogPolicyJsonCopy = {...jdCatalogPolicyJson}
    jdCatalogPolicyJsonCopy.views = views;
    const result = await edlPolicyService.createEdlRecord({...jdCatalogPolicyJsonCopy});
    const expectedCopy = {...edlPolicy};
    expectedCopy.views = expectedViews;
    delete expectedCopy.startDate;
    delete result.startDate;
    expect(result).toEqual({...expectedCopy, entitlement: expectedEnts, endDate: null});
  });

  it("should only aggregate most recent entitlements for a specific permission", async () => {
    process.env.multi_perm_enabled = 'true';
    const expectedEnts = [
    {
      classification: ['gicp3'],
      community: 'comm3',
      subcommunities: ['subcomm3'],
      countriesrepresented: ['cr3'],
      markers: ['tag3'],
    },{
      classification: ['gicp2'],
      community: 'comm2',
      subcommunities: ['subcomm2'],
      countriesrepresented: ['cr2'],
      markers: ['tag2'],
    }
    ];
    const availablePermission = {...jdCatalogPolicyJson, version: 1, status: 'AVAILABLE',updatedAt: "2019-07-02T15:59:27.793Z", entitlements: [createEntitlment(1), createEntitlment(2)]};
    const approvedPermission = {...jdCatalogPolicyJson, version: 2, status: 'APPROVED',updatedAt: "2020-07-02T15:59:27.793Z", entitlements: [createEntitlment(2)]};
    const otherPermission = {...jdCatalogPolicyJson, id: 'other-perm',group: 'SOME-LATEST_GROUP', status: 'AVAILABLE',updatedAt: "2020-07-10T15:59:27.793Z", entitlements: [createEntitlment(3)]}
    apiHelper.get.mockResolvedValue([
      availablePermission,
      approvedPermission,
      otherPermission
    ]);

    const result = await edlPolicyService.createEdlRecord(approvedPermission);
    const expectedCopy = {...edlPolicy};
    delete expectedCopy.startDate;
    delete result.startDate;
    expect(result).toEqual({...expectedCopy, entitlement: expectedEnts, endDate: null, roleBackup:'SOME-LATEST_GROUP', roleOwner: 'SOME-LATEST_GROUP', roleTechName:'SOME-LATEST_GROUP',roleName: 'SOME-LATEST_GROUP'})
  });

  it("should remove entitlements when permission is expired", async() => {
    process.env.multi_perm_enabled = 'true';

    const expiredPermission =  {
      ...jdCatalogPolicyJson,
      version: 2
    }   
    const latestAvailablePermission = {...jdCatalogPolicyJson};
    apiHelper.get.mockResolvedValue([latestAvailablePermission]);

    const result = await edlPolicyService.createEdlRecord(expiredPermission);

    const expectedEdlPolicy = {
      ...edlPolicy,
      startDate: new Date(timestamp).toISOString(),
      endDate: null,      
      entitlement: []
    }
    expect(result).toEqual(expectedEdlPolicy);
  });

  it("should aggregate specific permission with empty entitlments when fetch aggregated perms retuns empty", async () => {
    process.env.multi_perm_enabled = 'true';
    const expectedEnts = [];
    apiHelper.get.mockResolvedValue([]);

    const result = await edlPolicyService.createEdlRecord({...jdCatalogPolicyJson});
    const expectedCopy = {...edlPolicy};
    delete expectedCopy.startDate;
    delete result.startDate;
    expect(result).toEqual({...expectedCopy, entitlement: expectedEnts, endDate: null})
  });

  it("fetch aggregated perms fails", () => {
    process.env.multi_perm_enabled = 'true';
    apiHelper.get.mockRejectedValue('ahh!');

    const result = edlPolicyService.createEdlRecord({...jdCatalogPolicyJson});
    return expect(result).rejects.toEqual('ahh!');
  });

  it("fail for not having group (human)", async () => {
    await assertValidationError({ group: undefined }, '"group" is required');
  });

  it("fail for group not starting with AWS or EDG (human)", async () => {
    await assertValidationError({ group: 'invalid-group' }, "\"group\" with value \"invalid-group\" fails to match the must start with AWS or EDG pattern");
  });

  it("fail for not having known roleType (human or system)", async () => {
    await assertValidationError({ roleType: 'invalidRole' }, '"roleType" must be one of [human, system]');
  });

  it("fail for not having clientId, when roleType is system", async () => {
    await assertValidationError({ roleType: 'system', clientId: undefined }, '"clientId" is required');
  });

  it("set roleTechName to clientId, when roleType is system", async () => {
    //given
    const input = { ...jdCatalogPolicyJson, roleType: 'system', clientId: 'foobar' };
    //when
    const edlRecord = await edlPolicyService.createEdlRecord(input);
    //then
    expect(edlRecord.roleTechName).toEqual('foobar');
  });

  it("fail for Start date is not a date", async () => {
    await assertValidationError({ startDate: 'invalidStartDate' }, '"startDate" must be a valid ISO 8601 date');
  });

  it("fail for End date is a date, if present", async () => {
    await assertValidationError({ endDate: 'invalidEndDate' }, '"endDate" must be a valid ISO 8601 date');
  });

  it('Should create EDL permission record based on JD catalog permission', async() => {
    //given
    const expectedPolicy = { ...edlPolicy };
    //when
    const edlRecord = await edlPolicyService.createEdlRecord({...jdCatalogPolicyJson});
    //then
    expect(expectedPolicy).toEqual(edlRecord);
  });

  it('Should create EDL record if no Personal Info and Development are unavailable', async() => {
    //given
    let jdCatalogPolicy = {...jdCatalogPolicyJson};
    jdCatalogPolicy.entitlements[0].personalInformation = false;
    jdCatalogPolicy.entitlements[0].development = false;
    let expectedPolicy = { ...edlPolicy};
    expectedPolicy.entitlement[0].markers = [];
    //when
    const edlRecord = await edlPolicyService.createEdlRecord(jdCatalogPolicy);
    //then
    expect(expectedPolicy).toEqual(edlRecord);
  });

  it('Should get EDL Record URL from config', async() => {
    //given
    conf.getConfig.mockResolvedValue(config);
    //when
    const expectedEdlRecordUrl = await edlPolicyService.getEDLRecordUrl();
    //then
    expect(config.postPolicyUrl).toEqual(expectedEdlRecordUrl);
  });

  it("fail for not having valid Entitlement structure, if present", async () => {
    const inputCatalog = {...jdCatalogPolicyJson}
    delete inputCatalog.entitlements;
    const output = await edlPolicyService.validate(inputCatalog);
    expect(output.details[0].message).toEqual("\"entitlements\" is required");
  });

  it('should create a notification', async() => {
    const actualNotification = await edlPolicyService.createApprovalNotification();
    expect(actualNotification).toEqual({ details: ['EDL Approved']});
  });

  it('should be a system community', () => {
    const permission = { entitlements:  [ { community: { name: 'Systems' }} ] };
    const actualResponse = edlPolicyService.isSystemCommunity(permission);
    expect(actualResponse).toEqual(true);
  });

  it('should not be a system community', () => {
    const permission = { entitlements:  [ { community: { name: 'Product' } }] };
    const actualResponse = edlPolicyService.isSystemCommunity(permission);
    expect(actualResponse).toEqual(false);
  });

  async function assertValidationError(overrides = {}, errorMessage) {
    //given
    const jdCatalogPolicy = { ...jdCatalogPolicyJson, ...overrides };
    //when
    const error = edlPolicyService.validate(jdCatalogPolicy);
    //then
    const errorDetails = error.details.map(detail => detail.message);
    expect(errorMessage).toEqual(`${errorDetails}`);
  }

  function createEntitlment(suffix = 1) {
    return {
      gicp: {name: `GICP${suffix}`},
      community: {name: `COMM${suffix}`},
      subCommunity: {name: `SUBCOMM${suffix}`},
      countriesRepresented: [{name: `CR${suffix}`}],
      personalInformation: false,
      development: false,
      additionalTags: [`TAG${suffix}`]
    };
  }
});
