const edlDataTypeService = require("../../lib/services/edl-datatype-service");
const jdCatalogDatasetJson = require("../../test-data/jd-catalog-dataset.json");
const edlDataset = require("../../test-data/edl-dataset.json");
const conf = require("../../lib/conf.js");
const apiHelper = require("../../lib/util/api-helper");
const esHelper = require("../../lib/util/es-helper");
const md5 = require('md5');
const edlSchemaService = require("../../lib/services/edl-schema-service");

jest.mock("../../lib/conf");
jest.mock("../../lib/util/api-helper");
jest.mock("../../lib/util/es-helper");
jest.mock('md5');
jest.mock("../../lib/services/edl-schema-service");


const config = {
  dataTypeUrl: 'https://edl-catalog-api.vpn-devl.us.e03.c01.johndeerecloud.com/v1/types'
};

const dataTypeName = 'anyDataTypeName';
const dataTypeMount = '/any/datatype/';
const datatypeStorageLocation = "jd-us01-edl-prod-enhance-someEncodedId";
const datatypeAccount = "some aws account";
const datasetDetails = {
  name: dataTypeName,
  values: [
    { name: 'Databricks Mount Location', value: dataTypeMount },
    { name: 'S3 Bucket Name', value: datatypeStorageLocation },
    { name: 'Account', value: datatypeAccount },
    { name: 'Resource', value: 'Enterprise Data & Analytics Platform', url: 'https://confluence.deere.com/pages/viewpage.action?pageId=89358918' },
    { name: 'Resource', value: 'EDL Getting Started', url: 'https://confluence.deere.com/display/EDAP/EDL+Getting+Started' },
    { name: 'Resource', value: 'EDL Databricks Tutorials', url: 'https://confluence.deere.com/pages/viewpage.action?pageId=117932969' },
    { name: 'Resource', value: 'EDL + Databricks', url: 'https://confluence.deere.com/display/EDAP/Databricks' },
    { name: 'Resource', value: 'Ingesting Data', url: 'https://confluence.deere.com/display/EDAP/Ingesting+Data' },
  ]
}

const schemaName = 'anySchema';
const schemaMount = '/any/datatype/anySchema';
const versionTableName = 'any_historical_table_name_1_0_0';
const versionlessTableName = 'any_historical_table_name';
const version = '1.0.0'

const edlDataTypeResponse = {
  name: dataTypeName,
  databricksMountLocation: dataTypeMount,
  storageLocation: datatypeStorageLocation,
  storageAccount: datatypeAccount,
  schemas: ['com.deere.enterprise.datalake.test.'.concat(schemaName).concat('@').concat(version)],
  schemasMetadata: [
    {
      fullName: 'com.deere.enterprise.datalake.test.'.concat(schemaName).concat('@').concat(version),
      mountLocation: schemaMount,
      tableNames: [versionTableName, versionlessTableName],
    }
  ]
};


describe("DatasetService tests", () => {
  beforeEach(async () => {
    jest.spyOn(conf, 'getEnv').mockReturnValue('devl');
    conf.getConfig.mockResolvedValue(config);
    md5.mockImplementation(val => val);
    edlSchemaService.convertSchemas.mockResolvedValue([]);
    esHelper.findAndDeleteNonDeletedSchemas.mockRejectedValue('Boom');
  });

  afterEach(() => {
    edlSchemaService.convertSchemas.mockClear();
    apiHelper.getEDLMetadata.mockClear();
    esHelper.findAndDeleteNonDeletedSchemas.mockClear();
    edlSchemaService.validateSchemas.mockClear();
  })

  describe('joi errors', () => {
    it("should fail for not having phase", async () => {
      apiHelper.getEDLMetadata.mockResolvedValueOnce([]);
      const jdCatalogDataset = createJdCatalogDataset({ phase: undefined });
      const expectedError = "child \"phase\" fails because [\"phase\" is required]";
      let error = '';
      try{
        expect(await edlDataTypeService.validate(jdCatalogDataset)).rejects;
      } catch (err) {
        error = err;
      }
      expect(error.message).toEqual(expectedError);
    });

    it("should pass for having application name", async () => {
      apiHelper.getEDLMetadata.mockResolvedValueOnce([]);
      const jdCatalogDataset = createJdCatalogDataset({ application: 'test-myApplication' });
      expect(await edlDataTypeService.validate(jdCatalogDataset)).not.rejects;
    });
    
  });

  describe('validate schema delete tests', () => {
    const jdCatalogId = 'com.deere.enterprise.datalake.raw.cps.pega'
    const typeSearchObject = {
      "match_phrase": {
        "jdCatalogId": jdCatalogId + "@*"
      }
    };
    const edlSchemaId =  'some.catalog.id@1';
    const typeResponse = [{schemas: [edlSchemaId]}];
    const jdCatalogSchemaId = 'some.id@1';
    const versionlessCatalogSchemaId = jdCatalogSchemaId.split('@')[0];
    function schemaSearchObject(ids = [edlSchemaId]) {
      return {
        "index": "schemas3",
        "query": {
          "bool": {
            "filter": [
              {
                "terms": {
                  "_id": [...ids]
                }
              }
            ]
          }
        },
        "_source": ["jdCatalogId"],
        "size": 10000
      };
    }
    const schemasResponse = [ {jdCatalogId: jdCatalogSchemaId} ];

    it('should fail for having less linked schemas than EDL and none in deletedSchemas key', async () => {
      const linkedTypeResponse = [{schemas: [edlSchemaId, 'some.linked@1'] }];
      const expectedSchemaSeachObject = schemaSearchObject([edlSchemaId, 'some.linked@1']);
      const newSchemasResponse = schemasResponse.concat([{jdCatalogId: 'some.linked.id@1'}])
      apiHelper.getEDLMetadata
        .mockResolvedValueOnce(linkedTypeResponse)
        .mockResolvedValueOnce(newSchemasResponse);

      const jdCatalogDataset = createJdCatalogDataset({schemas: [], deletedSchemas: ['some.id'], linkedSchemas: []});

      let error = '';
      try {
        expect(await edlDataTypeService.validate(jdCatalogDataset)).rejects;
      } catch (err) {
        expect(err.message).toEqual('Schemas have been removed from the catalog and are not explicitly being deleted.');
        error = err;
      }

      expect(error.details[0].message).toEqual(`some.linked.id has been removed from catalog and is not being deleted`);
      expect(apiHelper.getEDLMetadata).toHaveBeenCalledWith('types', typeSearchObject);
      expect(apiHelper.getEDLMetadata).toHaveBeenCalledWith('', '', expectedSchemaSeachObject);
    });

    it('should fail for having less schemas than EDL and none in deletedSchemas key and list all missing', async () => {
      const newSchemaId = 'another.id@2.0.0';
      const versionlessNewSchemaId = newSchemaId.split('@')[0];
      const multipleSchemasResponse = [...schemasResponse, {jdCatalogId: newSchemaId}];

      apiHelper.getEDLMetadata
        .mockResolvedValueOnce(typeResponse)
        .mockResolvedValueOnce(multipleSchemasResponse);

      const jdCatalogDataset = createJdCatalogDataset({schemas: [], deletedSchemas: [], linkedSchemas: []});

      let error = '';
      try {
        expect(await edlDataTypeService.validate(jdCatalogDataset)).rejects
      } catch (err) {
        expect(err.message).toEqual('Schemas have been removed from the catalog and are not explicitly being deleted.');
        error = err;
      }

      expect(error.details[0].message).toEqual(`${versionlessCatalogSchemaId} has been removed from catalog and is not being deleted`);
      expect(error.details[1].message).toEqual(`${versionlessNewSchemaId} has been removed from catalog and is not being deleted`);
      expect(apiHelper.getEDLMetadata).toHaveBeenCalledWith('types', typeSearchObject);
      expect(apiHelper.getEDLMetadata).toHaveBeenCalledWith('', '', schemaSearchObject());
    });

    it('should fail for having less schemas than EDL and no deletedSchemas key', async () => {
      apiHelper.getEDLMetadata
        .mockResolvedValueOnce(typeResponse)
        .mockResolvedValueOnce(schemasResponse);
      const jdCatalogDataset = createJdCatalogDataset({schemas: [], linkedSchemas: [] });

      let error = '';
      try {
        expect(await edlDataTypeService.validate(jdCatalogDataset)).rejects
      } catch (err) {
        expect(err.message).toEqual('Schemas have been removed from the catalog and are not explicitly being deleted.');
        error = err;
      }

      expect(error.details[0].message).toEqual(`${versionlessCatalogSchemaId} has been removed from catalog and is not being deleted`)
    });

    it('Should delete the deleted schemas if they are not deleted from elastic search', async() => {
      //given
      const newSchemaId = 'another.id@2.0.0';
      const versionlessNewSchemaId = newSchemaId.split('@')[0];
      const multipleSchemasResponse = [...schemasResponse, {jdCatalogId: newSchemaId}];
      esHelper.findAndDeleteNonDeletedSchemas.mockResolvedValue([]);

      apiHelper.getEDLMetadata
        .mockResolvedValueOnce(typeResponse)
        .mockResolvedValueOnce(multipleSchemasResponse);

      const jdCatalogDataset = createJdCatalogDataset({schemas: [], deletedSchemas: [], linkedSchemas: []});

      //when
      await edlDataTypeService.validate(jdCatalogDataset)
      //then
      expect(esHelper.findAndDeleteNonDeletedSchemas).toBeCalledTimes(1);
    });

    it('should throw error if error in get edl metadata', () => {
      const error = new Error('some error');
      apiHelper.getEDLMetadata.mockRejectedValueOnce(error);
      const jdCatalogDataset = createJdCatalogDataset({schemas: [], deletedSchemas: ['some-id']});

      return expect(edlDataTypeService.validate(jdCatalogDataset)).rejects.toThrowError(error);
    });

    it('should not call edl search if no schemas are returned in type', async () => {
      apiHelper.getEDLMetadata.mockResolvedValueOnce([{schemas: []}]);

      const jdCatalogDataset = createJdCatalogDataset({schemas: [], deletedSchemas: ['some.id--2']});
      //when
      expect(await edlDataTypeService.validate(jdCatalogDataset)).resolves;
      expect(apiHelper.getEDLMetadata).toHaveBeenCalledWith('types', typeSearchObject);
      expect(apiHelper.getEDLMetadata).not.toHaveBeenCalledWith('', '', schemaSearchObject());
    });

    it('should return no error for no schemas, linked Schemas, or deletedSchemas in catalog', async () => {
      apiHelper.getEDLMetadata
        .mockResolvedValueOnce([{}]);

      var jdCatalogDataset = createJdCatalogDataset();
      jdCatalogDataset.schemas =[];
      jdCatalogDataset.linkedSchemas =[];
      delete jdCatalogDataset.deletedSchemas;
      //when
      expect(await edlDataTypeService.validate(jdCatalogDataset)).resolves;
      expect(apiHelper.getEDLMetadata).toHaveBeenCalledWith('types', typeSearchObject);
      expect(apiHelper.getEDLMetadata).not.toHaveBeenCalledWith('', '', schemaSearchObject([]));
    });

    it('should return no error for having same schemas as EDL but none in deletedSchemas key', async () => {
      const savedDataset = {
        schemas: [{id: 'some.catalog.id--1'}],
        linkedSchemas: [{id: 'some.linked.id--1'}],
        deletedSchemas: ['some.id--2']
      };
      const linkedTypeResponse = [{schemas: [edlSchemaId, 'some.linked@1'] }];
      const expectedSchemaSeachObject = schemaSearchObject([edlSchemaId, 'some.linked@1']);
      const newSchemasResponse = [...schemasResponse, {jdCatalogId: 'some.linked.id@1'}];
      edlSchemaService.validateSchemas.mockReturnValue(null);
      apiHelper.getEDLMetadata
        .mockResolvedValueOnce(linkedTypeResponse)
        .mockResolvedValueOnce(newSchemasResponse);

      const jdCatalogDataset = createJdCatalogDataset(savedDataset);
      //when
      expect(await edlDataTypeService.validate(jdCatalogDataset)).resolves;
      expect(apiHelper.getEDLMetadata).toHaveBeenCalledWith('types', typeSearchObject);
      expect(apiHelper.getEDLMetadata).toHaveBeenCalledWith('', '', expectedSchemaSeachObject);
    });

    it('should return no error for creating new schemas regardless of schemas in deletedSchemas key', async () => {
      const savedDataset = {
        schemas: [{id: 'some.catalog.id--1'}],
        linkedSchemas: [{id: 'some.linked.id--1'}],
        deletedSchemas: ['some.catalog.id--1']
      };
      const linkedTypeResponse = [{schemas: [edlSchemaId, 'some.linked@1'] }];
      const expectedSchemaSeachObject = schemaSearchObject([edlSchemaId, 'some.linked@1']);
      const newSchemasResponse = [];
      edlSchemaService.validateSchemas.mockReturnValueOnce(null);
      apiHelper.getEDLMetadata
        .mockResolvedValueOnce(linkedTypeResponse)
        .mockResolvedValueOnce(newSchemasResponse);


      const jdCatalogDataset = createJdCatalogDataset(savedDataset);
      //when
      expect(await edlDataTypeService.validate(jdCatalogDataset)).resolves;
      expect(apiHelper.getEDLMetadata).toHaveBeenCalledWith('types', typeSearchObject);
      expect(apiHelper.getEDLMetadata).toHaveBeenCalledWith('', '', expectedSchemaSeachObject);
    });
  });

  it('Should create EDL data type record based on JD catalog data type', async () => {
    //given
    const jdCatalogIdTypeResponse = [{ "name": "com.deere.enterprise.datalake.raw.cps.Pega" }];
    apiHelper.getEDLMetadata
      .mockResolvedValueOnce(jdCatalogIdTypeResponse);

    edlSchemaService.convertSchemas.mockResolvedValueOnce([...edlDataset.schemas]);

    const expectedEdlDataset = createEdlCatalogDataset();
    //when
    const edlRecord = await edlDataTypeService.createEdlRecord(createJdCatalogDataset());
    //then
    expect(edlRecord).toEqual(expectedEdlDataset);
  });

  it('Should create EDL data type record based on JD catalog data type without application name if not passed', async () => {
    //given
    const jdCatalogIdTypeResponse = [{ "name": "com.deere.enterprise.datalake.raw.cps.Pega" }];
    apiHelper.getEDLMetadata
      .mockResolvedValueOnce(jdCatalogIdTypeResponse);

    edlSchemaService.convertSchemas.mockResolvedValueOnce([...edlDataset.schemas]);

    const expectedEdlDataset = createEdlCatalogDataset();
    //when
    const edlRecord = await edlDataTypeService.createEdlRecord(createJdCatalogDataset());
    //then
    expect(edlRecord).toStrictEqual(expectedEdlDataset);
    expect(edlRecord).not.toHaveProperty('application');
    
  });

  it('Should create EDL data type record based on JD catalog data type with application name', async () => {
    //given
    const jdCatalogIdTypeResponse = [{ "name": "com.deere.enterprise.datalake.raw.cps.Pega" }];
    apiHelper.getEDLMetadata
      .mockResolvedValueOnce(jdCatalogIdTypeResponse);

    edlSchemaService.convertSchemas.mockResolvedValueOnce([...edlDataset.schemas]);
    const override = {
      application : 'test-myApplication'
    }
    const expectedEdlDataset = createEdlCatalogDataset(override);
    //when
    const edlRecord = await edlDataTypeService.createEdlRecord(createJdCatalogDataset(override));
    //then
    expect(edlRecord).toStrictEqual(expectedEdlDataset);
    expect(edlRecord).toHaveProperty('application', 'test-myApplication');
  });

  it('Should create EDL data type record when paths is missing', async () => {
    //given
    const jdCatalogIdTypeResponse = [{ "name": "com.deere.enterprise.datalake.raw.cps.Pega" }];
    apiHelper.getEDLMetadata
      .mockResolvedValueOnce(jdCatalogIdTypeResponse);

    edlSchemaService.convertSchemas.mockResolvedValueOnce([...edlDataset.schemas]);

    const expectedEdlDataset = createEdlCatalogDataset({paths: ['/']});
    let jdCatalogDataset = createJdCatalogDataset();
    delete jdCatalogDataset.paths;
    //when
    const edlRecord = await edlDataTypeService.createEdlRecord(jdCatalogDataset);
    //then
    expect(edlRecord).toEqual(expectedEdlDataset);
  });

  it('Should create EDL data type record when paths is given', async () => {
    //given
    const jdCatalogIdTypeResponse = [{ "name": "com.deere.enterprise.datalake.raw.cps.Pega" }];
    apiHelper.getEDLMetadata
      .mockResolvedValueOnce(jdCatalogIdTypeResponse);

    edlSchemaService.convertSchemas.mockResolvedValueOnce([...edlDataset.schemas]);

    const expectedEdlDataset = createEdlCatalogDataset({paths : ['/test1', '/test2']});
    const jdCatalogDataset = createJdCatalogDataset();
    jdCatalogDataset.paths = ['/test1', '/test2'];

    //when
    const edlRecord = await edlDataTypeService.createEdlRecord(jdCatalogDataset);
    //then
    expect(edlRecord).toEqual(expectedEdlDataset);
  });

  it('Should create EDL data type record for JD catalog data type phase Enhance', async () => {
    //given
    const jdCatalogIdTypeResponse = [{ "name": "com.deere.enterprise.datalake.raw.cps.Pega" }];

    apiHelper.getEDLMetadata
        .mockResolvedValue([])
        .mockResolvedValueOnce(jdCatalogIdTypeResponse);

    const jdDataSet = createJdCatalogDataset({phase: {id: 'Enhance', name: 'Enhance'}});
    let expectedEdlDataset = {
      ...edlDataset
    };
    expectedEdlDataset.phase = 'enhance';
    expectedEdlDataset.tables[0].schemaId = 'com.deere.enterprise.datalake.enhance.testschema@1.0.0';
    expectedEdlDataset.schemas.forEach(schema => schema.namespace = 'com.deere.enterprise.datalake.enhance');
    expectedEdlDataset.schemas[0].schema.compiled = 'ewogICJ0eXBlIjogInJlY29yZCIsCiAgIm5hbWUiOiAidGVzdHNjaGVtYSIsCiAgIm5hbWVzcGFjZSI6ICJjb20uZGVlcmUuZW50ZXJwcmlzZS5kYXRhbGFrZS5lbmhhbmNlIiwKICAic3RhdHVzIjogInRlc3QiLAogICJwYXJ0aXRpb24iOiBbCiAgICAiZGF0ZSIsCiAgICAicGFzc2VkIgogIF0sCiAgImlkIjogWwogICAgImtleSIsCiAgICAibmFtZSIKICBdLAogICJmaWVsZHMiOiBbCiAgICB7CiAgICAgICJuYW1lIjogImtleSIsCiAgICAgICJ0eXBlIjogImZsb2F0IiwKICAgICAgImRvYyI6ICJrZXkgZmllbGQiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJuYW1lIiwKICAgICAgInR5cGUiOiAic3RyaW5nIiwKICAgICAgImRvYyI6ICJuYW1lIGZpZWxkIgogICAgfSwKICAgIHsKICAgICAgIm5hbWUiOiAiZXh0cmFjdFRpbWUiLAogICAgICAidHlwZSI6IHsKICAgICAgICAidHlwZSI6ICJsb25nIiwKICAgICAgICAiZXh0cmFjdF90aW1lIjogdHJ1ZQogICAgICB9LAogICAgICAiZG9jIjogImV4dHJhY3QgdGltZSIKICAgIH0sCiAgICB7CiAgICAgICJuYW1lIjogImRlbGV0ZUluZCIsCiAgICAgICJ0eXBlIjogewogICAgICAgICJ0eXBlIjogImludCIsCiAgICAgICAgImRlbGV0ZV9pbmRpY2F0b3IiOiB0cnVlCiAgICAgIH0sCiAgICAgICJkb2MiOiAiZGVsZXRlIGluZGljYXRvciIKICAgIH0sCiAgICB7CiAgICAgICJuYW1lIjogInBhc3NlZCIsCiAgICAgICJ0eXBlIjogImJvb2xlYW4iLAogICAgICAiZG9jIjogInBhc3NlZCBmaWVsZCIKICAgIH0sCiAgICB7CiAgICAgICJuYW1lIjogImJpZ051bWJlciIsCiAgICAgICJ0eXBlIjogImRvdWJsZSIsCiAgICAgICJkb2MiOiAiYmlnIG51bWJlciIKICAgIH0sCiAgICB7CiAgICAgICJuYW1lIjogImRlY2ltYWxOdW1iZXIiLAogICAgICAidHlwZSI6IHsKICAgICAgICAidHlwZSI6ICJieXRlcyIsCiAgICAgICAgImxvZ2ljYWxUeXBlIjogImRlY2ltYWwiLAogICAgICAgICJwcmVjaXNpb24iOiAxMCwKICAgICAgICAic2NhbGUiOiAwCiAgICAgIH0sCiAgICAgICJkb2MiOiAiZGVjaW1hbCBudW1iZXIiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJkZWNpbWFsTm90TmVlZGVkIiwKICAgICAgInR5cGUiOiBbCiAgICAgICAgIm51bGwiLAogICAgICAgIHsKICAgICAgICAgICJ0eXBlIjogImJ5dGVzIiwKICAgICAgICAgICJsb2dpY2FsVHlwZSI6ICJkZWNpbWFsIiwKICAgICAgICAgICJwcmVjaXNpb24iOiAxMCwKICAgICAgICAgICJzY2FsZSI6IDAKICAgICAgICB9CiAgICAgIF0sCiAgICAgICJkb2MiOiAibm90IHJlcXVpcmVkIgogICAgfSwKICAgIHsKICAgICAgIm5hbWUiOiAiZGF0ZSIsCiAgICAgICJ0eXBlIjogewogICAgICAgICJ0eXBlIjogImludCIsCiAgICAgICAgImxvZ2ljYWxUeXBlIjogImRhdGUiCiAgICAgIH0sCiAgICAgICJkb2MiOiAiZGF0ZSBmaWVsZCIKICAgIH0sCiAgICB7CiAgICAgICJuYW1lIjogImRhdGVOb3ROZWVkZWQiLAogICAgICAidHlwZSI6IFsKICAgICAgICAibnVsbCIsCiAgICAgICAgewogICAgICAgICAgInR5cGUiOiAiaW50IiwKICAgICAgICAgICJsb2dpY2FsVHlwZSI6ICJkYXRlIgogICAgICAgIH0KICAgICAgXSwKICAgICAgImRvYyI6ICJub3QgcmVxdWlyZWQiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJ0aW1lc3RhbXAiLAogICAgICAidHlwZSI6IHsKICAgICAgICAidHlwZSI6ICJsb25nIiwKICAgICAgICAibG9naWNhbFR5cGUiOiAidGltZXN0YW1wLW1pY3JvcyIKICAgICAgfSwKICAgICAgImRvYyI6ICJ0aW1lc3RhbXAgZmllbGQiCiAgICB9CiAgXQp9';
    expectedEdlDataset.schemas[1].schema.compiled = 'ewogICJ0eXBlIjogInJlY29yZCIsCiAgIm5hbWUiOiAiYW5vdGhlcl90ZXN0X3NjaGVtYSIsCiAgIm5hbWVzcGFjZSI6ICJjb20uZGVlcmUuZW50ZXJwcmlzZS5kYXRhbGFrZS5lbmhhbmNlIiwKICAiZmllbGRzIjogWwogICAgewogICAgICAibmFtZSI6ICJub3ROZWVkZWQiLAogICAgICAidHlwZSI6IFsKICAgICAgICAibnVsbCIsCiAgICAgICAgImJ5dGVzIgogICAgICBdCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJuZWVkZWQiLAogICAgICAidHlwZSI6IHsKICAgICAgICAidHlwZSI6ICJpbnQiLAogICAgICAgICJpZCI6IHRydWUKICAgICAgfQogICAgfQogIF0KfQ==';
    expectedEdlDataset.schemas[2].schema.compiled = 'ewogICJ0eXBlIjogInJlY29yZCIsCiAgIm5hbWUiOiAiY2hhbm5lbF9tYXN0ZXJfYWNjdF9hZGRyZXNzX2RhdGEiLAogICJuYW1lc3BhY2UiOiAiY29tLmRlZXJlLmVudGVycHJpc2UuZGF0YWxha2UuZW5oYW5jZSIsCiAgImlkIjogWwogICAgImFjY3Rfa2V5IiwKICAgICJhY2N0X2xvY19pZCIKICBdLAogICJmaWVsZHMiOiBbCiAgICB7CiAgICAgICJuYW1lIjogImFjY3Rfa2V5IiwKICAgICAgInR5cGUiOiAiaW50IiwKICAgICAgImRvYyI6ICJOb25lIgogICAgfSwKICAgIHsKICAgICAgIm5hbWUiOiAiYWNjdF9sb2NfaWQiLAogICAgICAidHlwZSI6ICJpbnQiLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJhY2N0X3BoeV9hZGRyX2tleSIsCiAgICAgICJ0eXBlIjogImludCIsCiAgICAgICJkb2MiOiAiTm9uZSIKICAgIH0sCiAgICB7CiAgICAgICJuYW1lIjogImFjY3RfbWFpbF9hZGRyX2tleSIsCiAgICAgICJ0eXBlIjogImludCIsCiAgICAgICJkb2MiOiAiTm9uZSIKICAgIH0sCiAgICB7CiAgICAgICJuYW1lIjogImFjY3RfZmluX2FkZHJfa2V5IiwKICAgICAgInR5cGUiOiAiaW50IiwKICAgICAgImRvYyI6ICJOb25lIgogICAgfSwKICAgIHsKICAgICAgIm5hbWUiOiAiYWNjdF9waHlfbG9jX2xhdCIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJhY2N0X3BoeV9sb2NfbG9uZyIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJhY2N0X2xvY19zaWduX3R4dCIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJkZWVyZV90b19hY2N0X2VtYWlsX2lkIiwKICAgICAgInR5cGUiOiBbCiAgICAgICAgIm51bGwiLAogICAgICAgICJzdHJpbmciCiAgICAgIF0sCiAgICAgICJkb2MiOiAiTm9uZSIKICAgIH0sCiAgICB7CiAgICAgICJuYW1lIjogImN1c3RfdG9fYWNjdF9lbWFpbF9pZCIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJhY2N0X3VybF9hZGRyIiwKICAgICAgInR5cGUiOiBbCiAgICAgICAgIm51bGwiLAogICAgICAgICJzdHJpbmciCiAgICAgIF0sCiAgICAgICJkb2MiOiAiTm9uZSIKICAgIH0sCiAgICB7CiAgICAgICJuYW1lIjogInBoeV9hZGRyX2xpbmVfMSIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJwaHlfYWRkcl9saW5lXzIiLAogICAgICAidHlwZSI6IFsKICAgICAgICAibnVsbCIsCiAgICAgICAgInN0cmluZyIKICAgICAgXSwKICAgICAgImRvYyI6ICJOb25lIgogICAgfSwKICAgIHsKICAgICAgIm5hbWUiOiAicGh5X2FkZHJfY2l0eSIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJwaHlfYWRkcl9wb19jZCIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJwaHlfYWRkcl9zdGF0ZSIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJwaHlfYWRkcl9jb3VudHJ5IiwKICAgICAgInR5cGUiOiBbCiAgICAgICAgIm51bGwiLAogICAgICAgICJzdHJpbmciCiAgICAgIF0sCiAgICAgICJkb2MiOiAiTm9uZSIKICAgIH0sCiAgICB7CiAgICAgICJuYW1lIjogIm1haWxfYWRkcl9saW5lXzEiLAogICAgICAidHlwZSI6IFsKICAgICAgICAibnVsbCIsCiAgICAgICAgInN0cmluZyIKICAgICAgXSwKICAgICAgImRvYyI6ICJOb25lIgogICAgfSwKICAgIHsKICAgICAgIm5hbWUiOiAibWFpbF9hZGRyX2xpbmVfMiIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJtYWlsX2FkZHJfY2l0eSIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJtYWlsX2FkZHJfcG9fY2QiLAogICAgICAidHlwZSI6IFsKICAgICAgICAibnVsbCIsCiAgICAgICAgInN0cmluZyIKICAgICAgXSwKICAgICAgImRvYyI6ICJOb25lIgogICAgfSwKICAgIHsKICAgICAgIm5hbWUiOiAibWFpbF9hZGRyX3N0YXRlIiwKICAgICAgInR5cGUiOiBbCiAgICAgICAgIm51bGwiLAogICAgICAgICJzdHJpbmciCiAgICAgIF0sCiAgICAgICJkb2MiOiAiTm9uZSIKICAgIH0sCiAgICB7CiAgICAgICJuYW1lIjogIm1haWxfYWRkcl9jb3VudHJ5IiwKICAgICAgInR5cGUiOiBbCiAgICAgICAgIm51bGwiLAogICAgICAgICJzdHJpbmciCiAgICAgIF0sCiAgICAgICJkb2MiOiAiTm9uZSIKICAgIH0sCiAgICB7CiAgICAgICJuYW1lIjogImZpbl9hZGRyX2xpbmVfMSIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJmaW5fYWRkcl9saW5lXzIiLAogICAgICAidHlwZSI6IFsKICAgICAgICAibnVsbCIsCiAgICAgICAgInN0cmluZyIKICAgICAgXSwKICAgICAgImRvYyI6ICJOb25lIgogICAgfSwKICAgIHsKICAgICAgIm5hbWUiOiAiZmluX2FkZHJfY2l0eSIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJmaW5fYWRkcl9wb19jZCIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJmaW5fYWRkcl9zdGF0ZSIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJmaW5fYWRkcl9jb3VudHJ5IiwKICAgICAgInR5cGUiOiBbCiAgICAgICAgIm51bGwiLAogICAgICAgICJzdHJpbmciCiAgICAgIF0sCiAgICAgICJkb2MiOiAiTm9uZSIKICAgIH0sCiAgICB7CiAgICAgICJuYW1lIjogImJ1c25fcGhuX251bSIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJtYWlsX3Bobl9udW0iLAogICAgICAidHlwZSI6IFsKICAgICAgICAibnVsbCIsCiAgICAgICAgInN0cmluZyIKICAgICAgXSwKICAgICAgImRvYyI6ICJOb25lIgogICAgfSwKICAgIHsKICAgICAgIm5hbWUiOiAiZmluX3Bobl9udW0iLAogICAgICAidHlwZSI6IFsKICAgICAgICAibnVsbCIsCiAgICAgICAgInN0cmluZyIKICAgICAgXSwKICAgICAgImRvYyI6ICJOb25lIgogICAgfSwKICAgIHsKICAgICAgIm5hbWUiOiAiYnVzbl9mYXhfbnVtIiwKICAgICAgInR5cGUiOiBbCiAgICAgICAgIm51bGwiLAogICAgICAgICJzdHJpbmciCiAgICAgIF0sCiAgICAgICJkb2MiOiAiTm9uZSIKICAgIH0sCiAgICB7CiAgICAgICJuYW1lIjogIm1haWxfZmF4X251bSIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJmaW5fZmF4X251bSIsCiAgICAgICJ0eXBlIjogWwogICAgICAgICJudWxsIiwKICAgICAgICAic3RyaW5nIgogICAgICBdLAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJsb2FkX3RzIiwKICAgICAgInR5cGUiOiB7CiAgICAgICAgInR5cGUiOiAibG9uZyIsCiAgICAgICAgImxvZ2ljYWxUeXBlIjogInRpbWVzdGFtcC1taWNyb3MiCiAgICAgIH0sCiAgICAgICJkb2MiOiAiTm9uZSIKICAgIH0sCiAgICB7CiAgICAgICJuYW1lIjogInVwZGF0ZV90cyIsCiAgICAgICJ0eXBlIjogewogICAgICAgICJ0eXBlIjogImxvbmciLAogICAgICAgICJsb2dpY2FsVHlwZSI6ICJ0aW1lc3RhbXAtbWljcm9zIgogICAgICB9LAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJleHRyYWN0X3RpbWUiLAogICAgICAidHlwZSI6IHsKICAgICAgICAidHlwZSI6ICJsb25nIiwKICAgICAgICAiZXh0cmFjdF90aW1lIjogdHJ1ZQogICAgICB9LAogICAgICAiZG9jIjogIk5vbmUiCiAgICB9LAogICAgewogICAgICAibmFtZSI6ICJkZWxldGVfaW5kIiwKICAgICAgInR5cGUiOiB7CiAgICAgICAgInR5cGUiOiAiaW50IiwKICAgICAgICAiZGVsZXRlX2luZGljYXRvciI6IHRydWUKICAgICAgfSwKICAgICAgImRvYyI6ICJOb25lIgogICAgfQogIF0KfQ==';
    edlSchemaService.convertSchemas.mockResolvedValueOnce(expectedEdlDataset.schemas);

    //when
    const edlRecord = await edlDataTypeService.createEdlRecord(jdDataSet);
    //then
    expect(edlRecord).toEqual(expectedEdlDataset);
  });

  it('Should ignore table reference if no matching schema',  () => {
    //given
    const jdCatalogIdTypeResponse = [{ "name": "com.deere.enterprise.datalake.raw.cps.Pega" }];

    apiHelper.getEDLMetadata
        .mockResolvedValue([])
        .mockResolvedValueOnce(jdCatalogIdTypeResponse);

    const jdDataset = createJdCatalogDataset();
    jdDataset.tables[0].schemaId = 'some unknown schema reference';
    const expectedEdlDataset = createEdlCatalogDataset();
    expectedEdlDataset.tables = [];
    edlSchemaService.convertSchemas.mockResolvedValueOnce(expectedEdlDataset.schemas);

    return expect(edlDataTypeService.createEdlRecord(jdDataset)).resolves.toEqual(expectedEdlDataset);
  });

  it('Should not break if no tables in from jd catalog', async () => {
    //given
    const jdCatalogIdTypeResponse = [{ "name": "com.deere.enterprise.datalake.raw.cps.Pega" }];

    apiHelper.getEDLMetadata
        .mockResolvedValue([])
        .mockResolvedValueOnce(jdCatalogIdTypeResponse);

    const jdDataset = createJdCatalogDataset();
    delete jdDataset.tables;
    const expectedEdlDataset = createEdlCatalogDataset();
    expectedEdlDataset.tables = [];
    edlSchemaService.convertSchemas.mockResolvedValueOnce(expectedEdlDataset.schemas);

    //when
    const edlRecord = await edlDataTypeService.createEdlRecord(jdDataset);
    //then
    expect(edlRecord).toEqual(expectedEdlDataset);
  });

  it('Should get EDL Record URL from config', async () => {
    //given
    conf.getConfig.mockResolvedValueOnce(config);
    //when
    const expectedEdlRecordUrl = await edlDataTypeService.getEDLRecordUrl();
    //then
    expect(config.dataTypeUrl).toEqual(expectedEdlRecordUrl);
  });

  it("should get schema errors if no datatype errors", async () => {
    apiHelper.getEDLMetadata.mockResolvedValueOnce([]);
    const expectedSchemaValidation = createSchemaErrors([{message: 'something'}]);
    edlSchemaService.validateSchemas.mockReturnValueOnce(expectedSchemaValidation);

    const dataset = createJdCatalogDataset();
    delete dataset.schemas[0].name;

    let error= '';
    try{
      expect(await edlDataTypeService.validate(dataset)).rejects
    } catch (err) {
      error = err;
    }

    expect(error).toEqual(expectedSchemaValidation);
  });

  it("should return a notification from an edl response for a gvien data type with empty schema details if none are present in EDL", async () => {
    //given
    const sampleEdlDataTypeResponse = {
      name: dataTypeName,
      databricksMountLocation: dataTypeMount,
      storageLocation: datatypeStorageLocation,
      storageAccount: datatypeAccount,
      schemasMetadata: []
    };
    apiHelper.getDataType.mockResolvedValueOnce(sampleEdlDataTypeResponse);
    const expectedNotification = { details: { dataset: datasetDetails, schemas: [] } };
    //when
    const actualNotification = await edlDataTypeService.createApprovalNotification({ name: dataTypeName, schemas: [] }, 0);
    //then
    expect(actualNotification).toEqual(expectedNotification);
  });

  it("should try 10 times to if get data type fails to create a notification", async () => {
    //given
    const error = new Error('Boom');
    apiHelper.getDataType
        .mockRejectedValueOnce(error)
        .mockRejectedValueOnce(error)
        .mockRejectedValueOnce(error)
        .mockRejectedValueOnce(error)
        .mockRejectedValueOnce(error)
        .mockRejectedValueOnce(error)
        .mockRejectedValueOnce(error)
        .mockRejectedValueOnce(error)
        .mockRejectedValueOnce(error)
        .mockRejectedValueOnce(error);
    //when & then
    await expect(edlDataTypeService.createApprovalNotification('data.type.name', 0)).rejects.toEqual(error);
    expect(apiHelper.getDataType).toBeCalledTimes(10);
  });

  it('Should throw error if JD Catalog Id not exists but envionment name exists in EDL', async () => {
    //given
    const exampleDataset = createJdCatalogDataset();
    const jdCatalogIdSearchTerm = {
      "match_phrase": {
        "jdCatalogId": "com.deere.enterprise.datalake.raw.cps.pega@*"
      }
    };
    const jdCatalogIdSearchResponse = [];
    const environmentNameSearchTerm = {
      "match_phrase": {
        "name": "com.deere.enterprise.datalake.raw.cps_pega_raw"
      }
    };

    const environmentNameSearchResponse = [
      {
        "name": "com.deere.enterprise.datalake.raw.cps_pega_raw"
       }
    ];

    apiHelper.getEDLMetadata
      .mockResolvedValueOnce(jdCatalogIdSearchResponse)
      .mockResolvedValueOnce(environmentNameSearchResponse);

    //when && then
    await expect(edlDataTypeService.createEdlRecord(exampleDataset)).rejects.toEqual(new Error('Dataset name is not unique in EDL change the name'));
    expect(apiHelper.getEDLMetadata.mock.calls[0][0]).toEqual("types");
    expect(apiHelper.getEDLMetadata.mock.calls[0][1]).toEqual(jdCatalogIdSearchTerm);
    expect(apiHelper.getEDLMetadata.mock.calls[1][0]).toEqual("types");
    expect(apiHelper.getEDLMetadata.mock.calls[1][1]).toEqual(environmentNameSearchTerm);
  });

  it('Should return environment name if JD Catalog ID not exists and environment name not exists in EDL', async () => {
    //given
    const exampleDataset = createJdCatalogDataset();
    const jdCatalogIdSearchTerm = {
      "match_phrase": {
        "jdCatalogId": "com.deere.enterprise.datalake.raw.cps.pega@*"
      }
    };
    const jdCatalogIdSearchResponse = [];
    const environmentNameSearchTerm = {
      "match_phrase": {
        "name": "com.deere.enterprise.datalake.raw.cps_pega_raw"
      }
    };

    const environmentNameSearchResponse = [];
    apiHelper.getEDLMetadata
      .mockResolvedValueOnce(jdCatalogIdSearchResponse)
      .mockResolvedValueOnce(environmentNameSearchResponse);
    edlSchemaService.convertSchemas.mockResolvedValueOnce([]);

    //when
    const edlRecord = await edlDataTypeService.createEdlRecord(exampleDataset);
    //then
    expect(edlRecord.name).toEqual("com.deere.enterprise.datalake.raw.cps_pega_raw");
    expect(apiHelper.getEDLMetadata.mock.calls[0][1]).toEqual(jdCatalogIdSearchTerm);
    expect(apiHelper.getEDLMetadata.mock.calls[1][1]).toEqual(environmentNameSearchTerm);
  });

  it('Should return environment name if JD Catalog ID already exits and name is same as EDL Data catalog name', async () => {
    //given
    const exampleDataset = createJdCatalogDataset();
    const jdCatalogIdSearchTerm = {
      "match_phrase": {
        "jdCatalogId": "com.deere.enterprise.datalake.raw.cps.pega@*"
      }
    };
    const jdCatalogIdSearchResponse = [
      {
        "name": "com.deere.enterprise.datalake.raw.cps_pega_raw"
    }];
    apiHelper.getEDLMetadata
      .mockResolvedValue([])
      .mockResolvedValueOnce(jdCatalogIdSearchResponse);

    //when
    const edlRecord = await edlDataTypeService.createEdlRecord(exampleDataset);
    //then
    expect(edlRecord.name).toEqual("com.deere.enterprise.datalake.raw.cps_pega_raw");
    expect(apiHelper.getEDLMetadata.mock.calls[0][1]).toEqual(jdCatalogIdSearchTerm);
  });

  it('Should return EDL name if JD Catalog ID already exits and name is different in EDL Data catalog', async () => {
    //given
    const exampleDataset = createJdCatalogDataset();
    const jdCatalogIdSearchTerm = {
      "match_phrase": {
        "jdCatalogId": "com.deere.enterprise.datalake.raw.cps.pega@*"
      }
    };
    const jdCatalogIdSearchResponse = [
      {
        "name": "com.deere.enterprise.datalake.raw.cps.Pega.Raw"
      }
    ];
    apiHelper.getEDLMetadata
      .mockResolvedValue([])
      .mockResolvedValueOnce(jdCatalogIdSearchResponse);

    //when
    const edlRecord = await edlDataTypeService.createEdlRecord(exampleDataset);
    //then
    expect(edlRecord.name).toEqual("com.deere.enterprise.datalake.raw.cps.Pega.Raw");
    expect(apiHelper.getEDLMetadata.mock.calls[0][1]).toEqual(jdCatalogIdSearchTerm);
  });

  it("should fetch JD Catalog Id for schemas from existing JD Catalog dataset", async () => {
    apiHelper.getDataType.mockResolvedValueOnce({...edlDataTypeResponse});

    //given
    const edlDataSet = {
      name: dataTypeName,
      phase: 'enhance',
      schemas: [
        {
          jdCatalogId: "random uuid - 1",
          name: schemaName,
          namespace: 'com.deere.enterprise.datalake.test',
          version: version
        }
      ]
    }
    const expectedNotification =
      {
        details: {
          dataset: datasetDetails,
          schemas: [{
            id: "random uuid - 1",
            name: `com.deere.enterprise.datalake.test.${schemaName}@${version}`,
            values: [
              { name: 'Databricks Table', value: versionTableName },
              { name: 'Databricks Table', value: versionlessTableName },
              { name: 'Resource', value: 'EDL Warehouse', url: 'https://confluence.deere.com/display/EDAP/EDL+Warehouse' },
              { name: 'Resource', value: 'BI Tools or SQL Clients', url: 'https://confluence.deere.com/display/EDAP/Using+BI+Tools+or+SQL+Clients' },
            ]
          }]
        }
      }
    //when
    const actualNotification = await edlDataTypeService.createApprovalNotification(edlDataSet, 0);
    //then

    expect(actualNotification).toEqual(expectedNotification);
  });

  it('Should generate EDL Notification for Raw dataset which has no schemas', async () => {
    //given
    const simplifiedEDLDatatypeResponse = {
      name: dataTypeName,
      databricksMountLocation: dataTypeMount,
      storageLocation: datatypeStorageLocation,
      storageAccount: datatypeAccount
    };

    const edlDataSet = {
      name: dataTypeName,
      schemas: [],
      phase: 'raw'
    }
    const expectedNotification =
      {
        details: {
          dataset: datasetDetails,
          schemas: []
        }
      }
    apiHelper.getDataType.mockResolvedValueOnce(simplifiedEDLDatatypeResponse);
    //when
    const actualNotification = await edlDataTypeService.createApprovalNotification(edlDataSet, 0);

    //then
    expect(actualNotification).toEqual(expectedNotification);
  });


  it('Should generate EDL Notification for model dataset with schemas', async () => {
    //given
    const simplifiedEDLDatatypeResponse = {
      name: dataTypeName,
      databricksMountLocation: dataTypeMount,
      storageLocation: datatypeStorageLocation,
      storageAccount: datatypeAccount
    };

    const edlDataSet = {
      name: dataTypeName,
      phase: "moDEL",
      schemas: [{
        "name": "Test_Schema",
        "namespace": "com.deere.enterprise.datalake.enhance.core",
        "version": "0.0.1",
        "jdCatalogId": "9dce48f7-1787-4144-b222-0355a670fe74@1"
      }]
    };
    const expectedNotification = {
      details: {
        dataset: datasetDetails,
        schemas: [{
          id: "9dce48f7-1787-4144-b222-0355a670fe74--1",
          name: "com.deere.enterprise.datalake.enhance.core.Test_Schema@0.0.1",
          values: []
        }]
      }
    };
    apiHelper.getDataType.mockResolvedValueOnce(simplifiedEDLDatatypeResponse);
    //when
    const actualNotification = await edlDataTypeService.createApprovalNotification(edlDataSet, 0);

    //then
    expect(actualNotification).toEqual(expectedNotification);
  });

  it('Should generate EDL Notification for Raw dataset with schemas', async () => {
    //given
    const simplifiedEDLDatatypeResponse = {
      name: dataTypeName,
      databricksMountLocation: dataTypeMount,
      storageLocation: datatypeStorageLocation,
      storageAccount: datatypeAccount
    };

    const edlDataSet = {
      name: dataTypeName,
      phase: "raw",
      schemas: [{
        "name": "Test_Schema",
        "namespace": "com.deere.enterprise.datalake.enhance.core",
        "version": "0.0.1",
        "jdCatalogId": "9dce48f7-1787-4144-b222-0355a670fe74@1"
      }]
    };
    const expectedNotification = {
      details: {
        dataset: datasetDetails,
        schemas: [{
          id: "9dce48f7-1787-4144-b222-0355a670fe74--1",
          name: "com.deere.enterprise.datalake.enhance.core.Test_Schema@0.0.1",
          values: []
        }]
      }
    };
    apiHelper.getDataType.mockResolvedValueOnce(simplifiedEDLDatatypeResponse);
    //when
    const actualNotification = await edlDataTypeService.createApprovalNotification(edlDataSet, 0);

    //then
    expect(actualNotification).toEqual(expectedNotification);
  });

  it('Should throw exception and retry if schemas from EDL Datatype not matched with EDL Record', async () => {
    //given

    const newEdlDataSet = {
      name: dataTypeName,
      phase: 'enhance',
      schemas: [
        {
          jdCatalogId: "random uuid - 1",
          name: schemaName,
          namespace: 'com.deere.enterprise.datalake.test',
          version: version
        }
      ],
      linkedSchemas: []
    };

    const expectedNotification = {
      details: {
        dataset: datasetDetails,
        schemas: [
          {
            id: newEdlDataSet.schemas[0].jdCatalogId,
            name: newEdlDataSet.schemas[0].namespace + '.anySchema@1.0.0',
            values: [
              { name: "Databricks Table", value: "any_historical_table_name_1_0_0"},
              { name: "Databricks Table", value: "any_historical_table_name"},
              { name: 'Resource', value: 'EDL Warehouse', url: 'https://confluence.deere.com/display/EDAP/EDL+Warehouse' },
              { name: 'Resource', value: 'BI Tools or SQL Clients', url: 'https://confluence.deere.com/display/EDAP/Using+BI+Tools+or+SQL+Clients' },
            ]
          }
        ]
      }
    };

    let edlDataSetNoSchemas = {...edlDataTypeResponse};
    delete edlDataSetNoSchemas.schemasMetadata;
    apiHelper.getDataType
      .mockResolvedValueOnce(edlDataSetNoSchemas)
      .mockResolvedValueOnce({...edlDataTypeResponse});
    //when
    let response;
    try {
      response = await edlDataTypeService.createApprovalNotification(newEdlDataSet, 0);
    } catch (err) {
      expect(err).toEqual(new Error('Not a valid EDL response'));
    }

    //then
    expect(apiHelper.getDataType).toHaveBeenCalledTimes(2);
    expect(response).toEqual(expectedNotification);
  });

  it("should fail for missing community ", async () => {
    apiHelper.getEDLMetadata.mockResolvedValueOnce([]);
    edlSchemaService.validateSchemas.mockReturnValueOnce();
    const expectedError = createJoiError('classifications', 'community');

    let sampleDataset = createJdCatalogDataset();
    delete sampleDataset.classifications[0].community;

    return expect(edlDataTypeService.validate(sampleDataset)).rejects.toThrowError(expectedError);
  });

  it("should get combined schema errors, datatype errors, and missing errors", async () => {
    apiHelper.getEDLMetadata
      .mockResolvedValueOnce([{schemas: ['some-schema']}])
      .mockResolvedValueOnce([{jdCatalogId: 'some-missing-id@1'}]);
    edlSchemaService.validateSchemas.mockReturnValueOnce({details: [{message: "\"name\" is required"}]});

    let exampleDataset = createJdCatalogDataset();
    delete exampleDataset.schemas[0].name;
    delete exampleDataset.classifications[0].community;
    const expectedError = createJoiError('classifications', 'community');

    let err = '';
    try {
      expect(await edlDataTypeService.validate(exampleDataset)).rejects;
    } catch (error) {
      expect(error.message).toEqual(expectedError);
      err = error;
    }
    expect(err.details[0].message).toEqual("\"community\" is required");
    expect(err.details[1].message).toEqual("\"name\" is required");
    expect(err.details[2].message).toEqual("some-missing-id has been removed from catalog and is not being deleted");
  });

  it('should create a delete notification', async () => {
    const deleteResponse = {requestId: '1'};
    const expectedDeleteDatasetNotification = {details:
      [{name: 'Edl', value: `Successfully deleted from EDL. Request ID: ${deleteResponse.requestId}`}]
    };

    const response = await edlDataTypeService.createDeleteNotification(deleteResponse);

    expect(response).toEqual(expectedDeleteDatasetNotification);
  });

  it('should not be a system community', () => {
    const dataset = { classifications: [ { community: {name: 'Product'}}] };
    const actualResponse = edlDataTypeService.isSystemCommunity(dataset);
    expect(actualResponse).toEqual(false);
  });

  it('should be a system community', () => {
    const dataset = { classifications: [ { community: {name: 'Systems'}}] };
    const actualResponse = edlDataTypeService.isSystemCommunity(dataset);
    expect(actualResponse).toEqual(true);
  });

  function createJdCatalogDataset(overrides = {}) {
    return { ...jdCatalogDatasetJson, ...overrides};
  }

  function createEdlCatalogDataset(overrides = {}) {
    return { ...edlDataset, ...overrides};
  }

  function createJoiError(key, field) {
    return `child "${key}" fails because ["${key}" at position 0 fails because [child "${field}" fails because ["${field}" is required]]]`
  }

  function createSchemaErrors(details) {
    return {...new Error('Schema validation failed'), details };
  }
});
