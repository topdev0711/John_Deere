const AWS = require('aws-sdk');
const request = require('request-promise');
const conf = require('../lib/conf');

const awsCredentials = new AWS.Credentials('key', 'secret');
AWS.config.credentials = awsCredentials;
AWS.config.region = 'us-east-1';

describe('Creating a new permission', () => {
  const timeout = 100000;
  const testBucket = 'test-messages';
  const testPermissionName = 'AWS-GIT-DWIS-ADMIN';
  const testPermissionId = '09fb1afd-d348-42be-bc30-6e57e75f0977';
  const testPermissionVersion = 1;
  const testPermissionUri = `https://data-catalog-dev.deere.com/api-external/permissions/${testPermissionId}/versions/${testPermissionVersion}`;
  const edlPermissionFile = `${testPermissionName}-edl.json`;
  const testEdlPermissionApprovedMessage = 'EDL Approved';
  const permissionApprovalFile = `${testPermissionId}-${testPermissionVersion}-approve.json`;
  const testPermissionApprovedMessage = {
    id: testPermissionId,
    version: testPermissionVersion,
    action: 'permission approved',
    time: 'someTime',
    url: testPermissionUri
  };

  function sendQueueMessage(message) {
    const sqs = new AWS.SQS();
    const params = {
      QueueUrl: 'http://localhost:4576/queue/jd-catalog-notification-queue',
      MessageBody: JSON.stringify(message),
      DelaySeconds: 0
    };
    return sqs.sendMessage(params).promise();    
  }

  async function getS3File(key) {
    const s3 = new AWS.S3({ endpoint: `http://localhost:4572`, s3ForcePathStyle: true });
    await s3.waitFor('objectExists', { Bucket: testBucket, Key: key }).promise();
    return s3.getObject({ 
      Bucket: testBucket, 
      Key: key 
    }).promise().then(data => JSON.parse(data.Body.toString()));  
  }

  async function getToken() {
    const config = await conf.getConfig();
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded'
    };
    const body = {
      grant_type: 'client_credentials',
      client_id: config.edlOauthClientId,
      client_secret: config.edlOauthClientSecret
    };
    const response = await request({ method: 'POST', uri: config.edlOAuthUrl, headers, form: body });
    return JSON.parse(response).access_token;
  }

  async function fetchUrl(uri) {
    const token = await getToken();
    const params = {
      uri,
      headers: { 'Authorization': `Bearer ${token}` },
      json: true
    };
    return request(params);
  }

  beforeAll(done => {
    fetchUrl(testPermissionUri)
      .then(() => {
        done();
      })
      .catch(err => {
        console.log(err);
        throw new Error('unable to find test permission, so skipping tests');
      });
  });

  it('should successfully save the new permission', async () => {
    await sendQueueMessage(testPermissionApprovedMessage);

    try {
      const edlPermission = await getS3File(edlPermissionFile);
      expect(edlPermission.roleName).toEqual(testPermissionName);
      const jdcPermissionApproval = await getS3File(permissionApprovalFile);
      expect(jdcPermissionApproval.details[0]).toEqual(testEdlPermissionApprovedMessage);
    } catch (err) {
      console.log(err);
      throw new Error('was unable to verify file contents');
    }
  }, timeout);
});