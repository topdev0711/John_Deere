const AWS = require('aws-sdk');
const request = require('request-promise');
const conf = require('../lib/conf');

const awsCredentials = new AWS.Credentials('key', 'secret');
AWS.config.credentials = awsCredentials;
AWS.config.region = 'us-east-1';

describe('Creating a new dataset', () => {
  const timeout = 100000;
  const testBucket = 'test-messages';
  const testDataTypeId = 'com.deere.enterprise.datalake.enhance.smoketest';
  const testDatasetId = 'ea7ac3b8-e062-4b36-b1af-e38b70ac0ae9';
  const testDatasetVersion = 3;
  const testDatasetUri = `https://data-catalog-dev.deere.com/api-external/datasets/${testDatasetId}/versions/${testDatasetVersion}`;
  const edlDataTypeFile = `${testDataTypeId}-edl.json`;
  const datasetApprovalFile = `${testDatasetId}-${testDatasetVersion}-approve.json`;
  const testDatasetApprovedMessage = {
    id: testDatasetId,
    version: testDatasetVersion,
    action: "dataset approved",
    time: "someTime",
    url: testDatasetUri
  };

  function sendQueueMessage(message) {
    const sqs = new AWS.SQS();
    const params = {
      QueueUrl: 'http://localhost:4576/queue/jd-catalog-notification-queue',
      MessageBody: JSON.stringify(message),
      DelaySeconds: 0
    };
    return sqs.sendMessage(params).promise();    
  }

  async function getS3File(key) {
    const s3 = new AWS.S3({ endpoint: `http://localhost:4572`, s3ForcePathStyle: true });
    await s3.waitFor('objectExists', { Bucket: testBucket, Key: key }).promise();
    return s3.getObject({ 
      Bucket: testBucket, 
      Key: key 
    }).promise().then(data => JSON.parse(data.Body.toString()));  
  }

  async function getToken() {
    const config = await conf.getConfig();
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded'
    };
    const body = {
      grant_type: 'client_credentials',
      client_id: config.edlOauthClientId,
      client_secret: config.edlOauthClientSecret
    };
    const response = await request({ method: 'POST', uri: config.edlOAuthUrl, headers, form: body });
    return JSON.parse(response).access_token;
  }

  async function fetchUrl(uri) {
    const token = await getToken();
    const params = {
      uri,
      headers: { 'Authorization': `Bearer ${token}` },
      json: true
    };
    return request(params);
  }

  beforeAll(done => {
    fetchUrl(testDatasetUri)
      .then(() => {
        done();
      })
      .catch(err => {
        console.log(err);
        throw new Error('unable to find test dataset, so skipping tests');
      });
  });

  it('should successfully save the new dataset', async () => {
    await sendQueueMessage(testDatasetApprovedMessage);

    try {
      const edlDataType = await getS3File(edlDataTypeFile);
      const jdcDatasetApproval = await getS3File(datasetApprovalFile);
      expect(edlDataType.name).toEqual(testDataTypeId);
      expect(jdcDatasetApproval.details.dataset.name).toEqual(testDataTypeId);
    } catch (err) {
      console.log(err);
      throw new Error('was unable to verify file contents');
    }
  }, timeout);
});