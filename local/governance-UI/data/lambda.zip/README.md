# jd-catalog-to-edl-catalog-adapter
Gets notifications from jd catalog and update edl data catalog
[![Build Status](https://https://ci-edl.sharedservices-prod.us.i18.c01.johndeerecloud.com/buildStatus/icon?job=EDL/jd-catalog-to-edl-catalog-adapter/master)](https://ci-edl.sharedservices-prod.us.i18.c01.johndeerecloud.com/job/EDL/job/jd-catalog-to-edl-catalog-adapter/job/master/)
