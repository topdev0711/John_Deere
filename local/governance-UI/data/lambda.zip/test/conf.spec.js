const conf = require("../lib/conf.js");
const AWS = require('aws-sdk-mock');

describe('Config Test Suite', () => {
    beforeEach(() => {
        AWS.restore();
        process.env.environment = 'devl';
    });

    it('should fail to decrypt configs', () => {
        const decryptSpy = jest.fn().mockRejectedValue('Ahh!');
        AWS.mock('KMS', 'decrypt', decryptSpy);
        return conf.getConfig().catch(err => {
            expect(err).toEqual('Ahh!');
            decryptSpy.mockRestore();
        });
    });

    it('should return configs', async () => {
        AWS.mock('KMS', 'decrypt', jest.fn().mockResolvedValue({ Plaintext: 'decrypted' }));
        const actual = await conf.getConfig();
        const expectedConfig =  {
            region: 'us-east-1',
            dataTypeUrl: 'https://edl-catalog-api.vpn-devl.us.e03.c01.johndeerecloud.com/v1/types',
            postPolicyUrl: 'https://edl-entitlements-api.vpn-devl.us.e03.c01.johndeerecloud.com/v1/policies',
            edlOAuthUrl: 'https://johndeere.oktapreview.com/oauth2/ausazr82rqSWEnxwI0h7/v1/token',
            edlOauthClientId: '0oab61no9hmKkuuMA0h7',
            edlOauthClientSecret: 'decrypted',
            jdcUrl: "https://data-catalog-dev.deere.com",
            catalogESUrl: 'https://search-edl-data-catalog-3zq55guoniroi7uvyb5jq3zvaq.us-east-1.es.amazonaws.com'
        };
        expect(actual).toEqual(expectedConfig);
    });
});
