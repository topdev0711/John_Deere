const edlHandlerService = require("../../lib/services/edl-handler-service");
const edlDataTypeService = require("../../lib/services/edl-datatype-service");
const edlPermissionsService = require("../../lib/services/edl-permissions-service");
const apiHelper = require("../../lib/util/api-helper");

const nonEdlNotification = {details: [{name: 'Non edl', value: 'Approved but not sent to edl'}]};

const datasetUrl = 'test-dataset-url';
const datasetApprovedNotification = {
  id: 12345,
  version: 1,
  action: 'dataset approved',
  time: 'someTime',
  url: datasetUrl
};
const datasetDeleteNotification = {id: 12345, version: 1, action: 'delete dataset', time: 'someTime', url: datasetUrl};
const edlDeleteDatatypeResponse = {
  requestId: 'some-request-id'
};

const permissionUrl = 'test-permission-url';
const permissionNotification = {
  id: 12345,
  version: 1,
  action: 'permission approved',
  time: 'someTime',
  url: permissionUrl
};
const permissionEdlNotification = {details: ['EDL Approved']};
const inValidAction = {id: 12345, version: 1, action: 'invalid', time: 'someTime', url: datasetUrl};

const dataTypeName = 'anyDataTypeName';
const dataTypeMount = '/any/datatype/';
const schemaName = 'anySchema@1.0.0';
const schemaMount = '/any/datatype/anySchema';
const historicalName = 'any_historical_table_name';
const historicalUrl = 'https://anyHistoricalAddress';
const currentName = 'any_current_table_name';
const currentUrl = 'https://anyCurrentAddress';

const edlDataTypeResponse = {
  mountLocation: dataTypeMount,
  name: dataTypeName,
  schemasMetadata: [
    {
      currentTable: currentName,
      currentTableUrl: currentUrl,
      fullName: schemaName,
      historicalTable: historicalName,
      historicalTableUrl: historicalUrl,
      mountLocation: schemaMount
    }
  ]
}

const dataTypeNotification =
  {
    details: [
      {
        name: dataTypeName,
        details: [
          {name: 'mountLocation', value: dataTypeMount},
          {name: 'documentation', value: 'anyDocumentation'}
        ]
      },
      {
        name: schemaName,
        details: [
          {name: 'mountLocation', value: schemaMount},
          {name: 'historicalTable', value: historicalName, url: historicalUrl},
          {name: 'currentTable', value: currentName, url: currentUrl},
          {name: 'documentation', value: 'some documentation'}
        ]
      }
    ]
  }

jest.mock('../../lib/services/edl-datatype-service');
jest.mock('../../lib/services/edl-permissions-service');
jest.mock('../../lib/util/api-helper');

describe("Handler Service tests", () => {
  it('Should call reject JD Catalog data type if validation fails', async () => {
    //given
    const errorDetails = 'environmentName is required';
    const error = {
      details: [{
        message: errorDetails
      }]
    };
    apiHelper.get.mockResolvedValue({environmentName: undefined});
    edlDataTypeService.validate.mockRejectedValue(error);
    //when
    await edlHandlerService.handle({Records: [{body: JSON.stringify(datasetApprovedNotification)}]});
    //then
    expect(apiHelper.get).toBeCalledWith(datasetUrl);
    expect(apiHelper.reject).toBeCalledWith(datasetUrl, errorDetails);
  });

  it('Should call reject JD Catalog Permission if validation fails', async () => {
    //given
    const errorDetails = 'environmentName is required';
    const error = {
      details: [{
        message: errorDetails
      }]
    };
    apiHelper.get.mockResolvedValue({environmentName: undefined});
    edlPermissionsService.validate.mockRejectedValue(error);
    //when
    await edlHandlerService.handle({Records: [{body: JSON.stringify(permissionNotification)}]});
    //then
    expect(apiHelper.get).toBeCalledWith(permissionUrl);
    expect(apiHelper.approve).not.toHaveBeenCalled();
    expect(apiHelper.reject).toBeCalledWith(permissionUrl, errorDetails);
  });

  it('Should call approve JD Catalog data type if validation succeeded for a dataset', async () => {
    //given
    const edlRecordUrlFake = 'edl-data-set-url';
    apiHelper.get.mockResolvedValue({});
    edlDataTypeService.validate.mockResolvedValue(undefined);
    process.env.environment = 'prod';
    edlDataTypeService.isValidCommunity.mockReturnValue(true); //TODO set to false
    edlDataTypeService.createEdlRecord.mockResolvedValue(edlDataTypeResponse);
    edlDataTypeService.getEDLRecordUrl.mockResolvedValue(edlRecordUrlFake);
    apiHelper.saveToEdl.mockResolvedValue(edlDataTypeResponse);
    edlDataTypeService.createApprovalNotification.mockReturnValue(dataTypeNotification);

    const expectedResponse = 'some response';
    apiHelper.approve.mockResolvedValue(expectedResponse);

    //when
    const actualResponse = await edlHandlerService.handle({Records: [{body: JSON.stringify(datasetApprovedNotification)}]});

    //then
    expect(apiHelper.get).toBeCalledWith(datasetUrl);
    expect(apiHelper.saveToEdl).toBeCalledWith(edlRecordUrlFake, edlDataTypeResponse);
    expect(apiHelper.approve).toBeCalledWith(datasetUrl, dataTypeNotification, true);
    expect(apiHelper.reject).not.toHaveBeenCalled();
    expect(actualResponse).toEqual([expectedResponse]);
  });

  it('Should call approve JD Catalog data type if validation succeeded for a permission', async () => {
    //given
    process.env.environment = 'prod';
    const edlFakeRecord = {name: 'fake-edl-record'};
    const edlRecordUrlFake = 'edl-policy-url';
    apiHelper.get.mockResolvedValue({});
    edlPermissionsService.validate.mockResolvedValue(undefined);
    edlPermissionsService.isValidCommunity.mockReturnValue(false);
    edlPermissionsService.createEdlRecord.mockResolvedValue(edlFakeRecord);
    edlPermissionsService.getEDLRecordUrl.mockResolvedValue(edlRecordUrlFake);
    edlPermissionsService.createApprovalNotification.mockReturnValue(permissionEdlNotification);
    //when
    permissionNotification.sendEmailFlag = false;
    await edlHandlerService.handle({Records: [{body: JSON.stringify(permissionNotification)}]});
    //then
    expect(apiHelper.get).toBeCalledWith(permissionUrl);
    expect(apiHelper.saveToEdl).toBeCalledWith(edlRecordUrlFake, edlFakeRecord);
    expect(apiHelper.approve).toBeCalledWith(permissionUrl, permissionEdlNotification, false);
    expect(apiHelper.reject).not.toHaveBeenCalled();
  });

  it('Should not call send to edl when a non production environment jd catalog object does not belong to the Systems community', async () => {
    //given
    apiHelper.get.mockResolvedValue({});
    edlDataTypeService.validate.mockResolvedValue(undefined);
    edlDataTypeService.isValidCommunity.mockReturnValue(false);
    process.env.environment = 'devl';
    //when
    await edlHandlerService.handle({Records: [{body: JSON.stringify(datasetApprovedNotification)}]});
    //then
    expect(apiHelper.saveToEdl).not.toHaveBeenCalled();
  });

  it('Should call send to edl when a non production environment jd catalog object does belongs to the Systems community', async () => {
    //given
    apiHelper.get.mockResolvedValue({});
    edlDataTypeService.validate.mockResolvedValue(undefined);
    edlDataTypeService.isValidCommunity.mockReturnValue(true);
    process.env.environment = 'devl';
    //when
    await edlHandlerService.handle({Records: [{body: JSON.stringify(datasetApprovedNotification)}]});
    //then
    expect(apiHelper.saveToEdl).toHaveBeenCalled();
  });

  it('Should call reject JD Catalog data type if validation succeeded and EDL throws Bad Data exception', async () => {
    //given
    const edlFakeRecord = {name: 'fake-edl-record'};
    const edlRecordUrlFake = 'edl-policy-url';
    apiHelper.get.mockResolvedValue({});
    edlDataTypeService.validate.mockResolvedValue(undefined);
    process.env.environment = 'devl';
    edlDataTypeService.createEdlRecord.mockResolvedValue(edlFakeRecord);
    edlDataTypeService.getEDLRecordUrl.mockResolvedValue(edlRecordUrlFake);
    let edlPostResponse = {
      "name": "StatusCodeError",
      "statusCode": 400,
      "message": "400 - \"{\\\"errorMessage\\\":\\\"Error: type with environment EDL and phase us-east-1 not accepted\\\"}\"",
      "error": JSON.stringify({"errorMessage": "Error: type with environment EDL and phase us-east-1 not accepted"}),
    };
    apiHelper.saveToEdl.mockRejectedValue(edlPostResponse);
    //when
    await edlHandlerService.handle({Records: [{body: JSON.stringify(datasetApprovedNotification)}]});
    //then
    expect(apiHelper.get).toBeCalledWith(datasetUrl);
    expect(apiHelper.saveToEdl).toBeCalledWith(edlRecordUrlFake, edlFakeRecord);
    expect(apiHelper.reject).toBeCalledWith(datasetUrl, edlPostResponse.message);
    expect(apiHelper.approve).not.toHaveBeenCalled();
  });

  it('Should call reject JD Catalog permission if validation succeeded and EDL throws Bad Data exception', async () => {
    //given
    const edlFakeRecord = {name: 'fake-edl-record'};
    const edlRecordUrlFake = 'edl-policy-url';
    apiHelper.get.mockResolvedValue({});
    edlPermissionsService.validate.mockResolvedValue(undefined);
    process.env.environment = 'prod';
    edlPermissionsService.createEdlRecord.mockResolvedValue(edlFakeRecord);
    edlPermissionsService.getEDLRecordUrl.mockResolvedValue(edlRecordUrlFake);
    let edlPostResponse = {
      "name": "StatusCodeError",
      "statusCode": 400,
      "message": "400 - \"{\\\"errorMessage\\\":\\\"Error: type with environment EDL and phase us-east-1 not accepted\\\"}\"",
      "error": JSON.stringify({"errorMessage": "Error: type with environment EDL and phase us-east-1 not accepted"}),
    };
    apiHelper.saveToEdl.mockRejectedValue(edlPostResponse);
    //when
    await edlHandlerService.handle({Records: [{body: JSON.stringify(permissionNotification)}]});
    //then
    expect(apiHelper.get).toBeCalledWith(permissionUrl);
    expect(apiHelper.saveToEdl).toBeCalledWith(edlRecordUrlFake, edlFakeRecord);
    expect(apiHelper.reject).toBeCalledWith(permissionUrl, edlPostResponse.message);
    expect(apiHelper.approve).not.toHaveBeenCalled();
  });

  it('Should not process request for invalid action', async () => {
    //when
    await edlHandlerService.handle({Records: [{body: JSON.stringify(inValidAction)}]});
    //then
    expect(apiHelper.get).not.toHaveBeenCalled();
    expect(apiHelper.approve).not.toHaveBeenCalled();
    expect(apiHelper.reject).not.toHaveBeenCalled();
    expect(apiHelper.saveToEdl).not.toHaveBeenCalled();
  });

  it('Should call reject JD Catalog if unique-name validation fails', async () => {
    //given
    const error = new Error("Dataset name is not unique in EDL; change the name");
    apiHelper.get.mockResolvedValue({});
    apiHelper.reject.mockResolvedValue("");
    edlDataTypeService.validate.mockResolvedValue(undefined);
    edlDataTypeService.createEdlRecord.mockRejectedValue(error);
    process.env.environment = 'devl';
    //when
    await edlHandlerService.handle({Records: [{body: JSON.stringify(datasetApprovedNotification)}]});
    //then
    expect(apiHelper.get).toBeCalledWith(datasetUrl);
    expect(apiHelper.reject).toBeCalledWith(datasetUrl, 'Dataset name is not unique in EDL; change the name');
    expect(apiHelper.approve).not.toHaveBeenCalled();
  });

  it('Should call reject JD Catalog dataset if delete called and EDL throws exception', async () => {
    //given
    apiHelper.get.mockResolvedValue({});
    edlDataTypeService.validate.mockResolvedValue(undefined);
    process.env.environment = 'devl';
    edlDataTypeService.createEdlRecord.mockReturnValue(edlDataTypeResponse);
    const errorMessage = "Some error"
    const edlDeleteResponse = {
      "name": "some other error",
      "statusCode": 500,
      "message": "500 - \"{\\\"errorMessage\\\":\\\"Error: type with environment EDL and phase us-east-1 not accepted\\\"}\"",
      "error": JSON.stringify({"errorMessage": errorMessage}),
    };
    apiHelper.deleteFromEdl.mockRejectedValue(edlDeleteResponse);
    apiHelper.reject.mockResolvedValue('rejected');
    apiHelper.approve.mockResolvedValue('approved');
    const message = {Records: [{body: JSON.stringify(datasetDeleteNotification)}]}

    await expect(edlHandlerService.handle(message)).resolves.toEqual(['rejected']);
    expect(apiHelper.get).toBeCalledWith(datasetUrl);
    expect(edlDataTypeService.getEDLRecordUrl).not.toHaveBeenCalled();
    expect(apiHelper.saveToEdl).not.toHaveBeenCalled();
    expect(apiHelper.deleteFromEdl).toHaveBeenCalledWith(dataTypeName);
    expect(apiHelper.reject).toBeCalledWith(expect.anything(), edlDeleteResponse.message);
    expect(apiHelper.approve).not.toBeCalled();
  });

  it('Should call reject JD Catalog dataset if delete succeeded and EDL throws Bad Data exception', async () => {
    //given
    apiHelper.get.mockResolvedValue({});
    edlDataTypeService.validate.mockResolvedValue(undefined);
    process.env.environment = 'devl';
    edlDataTypeService.createEdlRecord.mockReturnValue(edlDataTypeResponse);
    const errorMessage = "Some error"
    const edlDeleteResponse = {
      "name": "StatusCodeError",
      "statusCode": 400,
      "message": "400 - \"{\\\"errorMessage\\\":\\\"Error: type with environment EDL and phase us-east-1 not accepted\\\"}\"",
      "error": JSON.stringify({"errorMessage": errorMessage}),
    };
    apiHelper.deleteFromEdl.mockRejectedValue(edlDeleteResponse);

    //when
    await edlHandlerService.handle({Records: [{body: JSON.stringify(datasetDeleteNotification)}]});

    //then
    expect(apiHelper.get).toBeCalledWith(datasetUrl);
    expect(edlDataTypeService.getEDLRecordUrl).not.toHaveBeenCalled();
    expect(apiHelper.saveToEdl).not.toHaveBeenCalled();
    expect(apiHelper.deleteFromEdl).toHaveBeenCalledWith(dataTypeName);
    expect(apiHelper.approve).not.toHaveBeenCalled();
    expect(apiHelper.reject).toBeCalledWith(datasetUrl, edlDeleteResponse.message);
  });

  it('should submit a delete request to EDL if notification action is delete and approve if successful', async () => {
    //given
    const expectedDeleteDatasetNotification = {
      details:
        [{name: 'Edl', value: `Successfully deleted from EDL. Request ID: ${edlDeleteDatatypeResponse.requestId}`}]
    };
    apiHelper.get.mockResolvedValue({});
    edlDataTypeService.validate.mockResolvedValue(undefined);
    process.env.environment = 'devl';
    apiHelper.deleteFromEdl.mockReturnValue(edlDeleteDatatypeResponse);
    edlDataTypeService.createEdlRecord.mockReturnValue(edlDataTypeResponse);
    const expectedResponse = 'some-response';
    apiHelper.approve.mockResolvedValue(expectedResponse)
    edlDataTypeService.createDeleteNotification.mockReturnValue(expectedDeleteDatasetNotification);

    datasetDeleteNotification.sendEmailFlag = true;
    //when
    const actualResponse = await edlHandlerService.handle({Records: [{body: JSON.stringify(datasetDeleteNotification)}]});

    //then
    expect(apiHelper.get).toBeCalledWith(datasetUrl);
    expect(edlDataTypeService.getEDLRecordUrl).not.toHaveBeenCalled();
    expect(apiHelper.saveToEdl).not.toHaveBeenCalled();
    expect(apiHelper.deleteFromEdl).toHaveBeenCalledWith(dataTypeName);
    expect(apiHelper.approve).toBeCalledWith(datasetUrl, expectedDeleteDatasetNotification, true);
    expect(actualResponse).toEqual([expectedResponse]);
  });
});
