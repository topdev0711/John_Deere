const edlSchemaService = require('../../lib/services/edl-schema-service');
const {deleteIndicator, extractTime, id, none} = require('../../lib/services/edl-schema-service');
const jdCatalogDataset = require("../../test-data/jd-catalog-dataset.json");
const apiHelper = require("../../lib/util/api-helper");

jest.mock("../../lib/util/api-helper");

describe('Schema validations', () => {
  function noAnnotationSchema() {
    return {
      'environmentName': 'some.env.name',
      'testing': false,
      "partitionedBy": [],
      'name': 'alert.mk_alert_defn_localized_dm',
      'fields': [createField('mk_alert_defn_local_sk'), createField('index_cnt')],
      'updatedAt': '2019-06-10T16:45:31.446Z',
      'createdAt': '2019-06-10T16:45:31.446Z',
      'id': 'alert.mk_alert_defn_localized_dm@3.0.0',
      'documentation': none,
      'description': none,
      'createdBy': 'js91162',
      'version': '1',
      'updatedBy': 'js91162'
    }
  };
  function createField(name, attributeName = none, nullable = false, dataTypeName = 'long', scale = 0, precision=10) {
    let result = {
      'attribute': attributeName,
      'datatype':  dataTypeName,
      'description': none,
      'id': '78',
      nullable,
      name
    }
    if(dataTypeName=='decimal') {
      result = {
        ...result,
        'scale': scale,
        'precision' : precision
      }
    }
    return result;
  }

  function createExpectedEdlSchemaQuery(ids) {
    return {
      "index": "schemas3",
      "query": {
        "bool": {
          "should": ids.map(id => {
            return {
              "wildcard": {
                "jdCatalogId.keyword": {
                  "value": id
                }
              }
            } 
          })
        }
      },
      "_source": ["jdCatalogId", "version","name","namespace"],
      "size": 10000
    };
  }

  it('should pass validation', () => {
    const result = edlSchemaService.validateSchemas([noAnnotationSchema()]);
    expect(result).toEqual(null);
  });

  it('should use provide the name as <schema>@<version> for failure messages', () => {
    const schema = noAnnotationSchema();
    schema.fields = [];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual('"fields" must contain at least 1 items');
  });


  it('should fail to save when fields array is empty', () => {
    const schema = noAnnotationSchema();
    schema.fields = [];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual('"fields" must contain at least 1 items');
    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should fail to save when field name contains special chars', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('foo.bar#$%')];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual('"name" with value "foo.bar#$%" fails to match the cannot contain special characters pattern');
  });

  it('Should fail to save when Schema field is undefined', () => {
    const schema = noAnnotationSchema();
    delete schema.fields;

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("\"fields\" is required");
    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should fail when the field type is not lowercase', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('someField', none, false, 'LONG')];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("\"datatype\" must be one of [string, boolean, short, int, long, float, double, bytes, timestamp, date, decimal]");
    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should fail when the field type is not valid', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('someField', none, false, 'someInvalidType')];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("\"datatype\" must be one of [string, boolean, short, int, long, float, double, bytes, timestamp, date, decimal]");
    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should pass when datatype is extract time and attribute is long', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('datatypeObject', extractTime, false, 'long')];

    const actualError = edlSchemaService.validateSchemas([schema]);
    expect(actualError).toEqual(null);
  });  

  it('should pass when datatype is extract timestamp and attribute is date', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('datatypeObject', extractTime, false, 'date')];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError).toEqual(null);
  });  

  it('should pass when datatype is extract timestamp and attribute is timestamp', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('datatypeObject', extractTime, false, 'timestamp')];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError).toEqual(null);
  });  

  it('should fail when datatype is extract timestamp and attribute is not date timestamp or long', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('datatypeObject', extractTime, false, 'decimal', 1 , 1)];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("Invalid Schema: alert.mk_alert_defn_localized_dm@1. extract time must be a int, long, timestamp, date");
    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });  

  it('should fail when decimal scale is larger than precision', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('datatypeObject', none, false, 'decimal', 2 , 1)];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("\"scale\" must be less than or equal to 1");
    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should validate that datatype is be successful with a valid decimal', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('datatypeObject', none, false, 'decimal', 0, 1)];

    const response = edlSchemaService.validateSchemas([schema]);
    expect(response).toEqual(null);
  });

  it('should fail when datatype is decimal and scale is missing', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('datatypeObject', none, false, 'decimal')];
    delete schema.fields[0].scale
    schema.fields[0].precision = 1;

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("\"scale\" is required");
    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should fail when datatype is decimal and scale is less than 0', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('datatypeObject', none, false, 'decimal',-1, 1)];

    const actualError = edlSchemaService.validateSchemas([schema]);
    expect(actualError.details[0].message).toEqual("\"scale\" must be larger than or equal to 0");

    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should fail when datatype is decimal and precision is less than 1', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('datatypeObject', none, false, 'decimal', 1, 0)];

    const actualError = edlSchemaService.validateSchemas([schema]);
    expect(actualError.details[0].message).toEqual("\"scale\" must be less than or equal to 0");

    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should fail when datatype is decimal and precision is greater than 38', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('datatypeObject', none, false, 'decimal', 1, 39)];

    const actualError = edlSchemaService.validateSchemas([schema]);
    expect(actualError.details[0].message).toEqual("\"precision\" must be less than or equal to 38");

    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should fail when datatype is decimal and scale is greater than 38', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('datatypeObject', none, false, 'decimal', 39, 39)];

    const actualError = edlSchemaService.validateSchemas([schema]);
    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should fail when datatype is decimal and scale is missing fail when datatype is decimal and precision is missing', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('datatypeObject', none, false, 'decimal')];
    delete schema.fields[0].precision
    schema.fields[0].scale = 1;

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("\"scale\" references \"precision\" which is not a number");
    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should fail when testing attr is invalid', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('datatypeObject', none, false, 'string')];
    schema.testing = "abc";

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual( "\"testing\" must be a boolean");
    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should fail to save when schema has duplicate field names', () => {
    const field = createField('mk_alert_defn_local_sk');
    const schema = noAnnotationSchema();
    schema.fields = [field, field];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("Invalid Schema: alert.mk_alert_defn_localized_dm@1. Found duplicate fields: mk_alert_defn_local_sk");
    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should fail to save when schema name is an empty string', () => {
    const schema = noAnnotationSchema();
    schema.name = '';

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("\"name\" is not allowed to be empty");
    expect(actualError.details[0].name).toEqual(schema.name +'@1');
  });

  it('should fail to save schema when all fields in the id annotation are in the partition annotation', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('someField', id)];
    schema.partitionedBy = ['someField'];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("Invalid Schema: alert.mk_alert_defn_localized_dm@1. Cannot have a partition containing all id fields");
    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should fail when field has special character in the name', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('nameWithSpecialChars#!')];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("\"name\" with value \"nameWithSpecialChars#!\" fails to match the cannot contain special characters pattern");
    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should fail when partition has nullable fields', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('someField'), createField('anotherField', none, true)];
    schema.partitionedBy = [ 'someField', 'anotherField' ];
    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("Cannot have a partition with nullable fields. Found nullable fields: anotherField");
    expect(actualError.details[0].name).toEqual('alert.mk_alert_defn_localized_dm@1');
  });

  it('should succeed when schema has id and partition annotations that use different fields', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('someField', id), createField('anotherField', none)];
    schema.partitionedBy = ['anotherField'];

    const result = edlSchemaService.validateSchemas([schema]);
    expect(result).toEqual(null);
  });

  it('should succeed when partition has nullable field that is set to false', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('someField')];
    schema.partitionedBy = ['someField'];

    const result = edlSchemaService.validateSchemas([schema]);

    expect(result).toEqual(null);
  });

  it('should fail when composite id contains a nullable field', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('someField', id, true)];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("Cannot have a id with nullable fields. Found nullable fields: someField");
  });

  it('should fail when field in partition annotation does not exist', () => {
    const schema = noAnnotationSchema();
    const nonExistentField = 'someNonExistantField';
    schema.partitionedBy = [nonExistentField];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("Invalid Schema: alert.mk_alert_defn_localized_dm@1. Missing fields defined in the partition: someNonExistantField");
  });

  it('should fail when delete indicator is on more than one field', () => {
    const schema = noAnnotationSchema();
    schema.fields = [
      createField('mk_alert_defn_local_sk', deleteIndicator),
      createField('someOtherField', deleteIndicator)
    ];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("Invalid Schema: alert.mk_alert_defn_localized_dm@1. Cannot have multiple fields with delete indicator");
  });

  it('should fail when delete indicator is nullable', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('someField', deleteIndicator, true, 'int')];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("Cannot have a delete indicator with nullable fields. Found nullable fields: someField");
  });

  it('should fail when delete indicator is not a numeric value', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('someField', deleteIndicator, false, 'string')];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("Invalid Schema: alert.mk_alert_defn_localized_dm@1. delete indicator must be a int, long");
  });

  it('should fail when extract timestamp is on more than one field', () => {
    const schema = noAnnotationSchema();
    schema.fields = [
      createField('mk_alert_defn_local_sk', extractTime),
      createField('someOtherField', extractTime)
    ];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("Invalid Schema: alert.mk_alert_defn_localized_dm@1. Cannot have multiple fields with extract time");
  });

  it('should fail when extract timestamp is nullable', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('someField', extractTime, true)];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("Cannot have a extract time with nullable fields. Found nullable fields: someField");
  });

  it('should fail when extract timestamp is not a numeric value', () => {
    const schema = noAnnotationSchema();
    schema.fields = [createField('someField', extractTime, false, 'string')];

    const actualError = edlSchemaService.validateSchemas([schema]);

    expect(actualError.details[0].message).toEqual("Invalid Schema: alert.mk_alert_defn_localized_dm@1. extract time must be a int, long, timestamp, date");
  });

  it('should merge multiple failures into the same error', () => {
    const schema = noAnnotationSchema();
    const field = createField('mk_alert_defn_local_sk');
    schema.fields = [createField('someField', extractTime, false, 'string'), field, field];

    const actualError = edlSchemaService.validateSchemas([schema, noAnnotationSchema()]);

    const errorDetails = actualError.details.map(detail => detail.message);
    expect(errorDetails).toContain('Invalid Schema: alert.mk_alert_defn_localized_dm@1. Found duplicate fields: someField,mk_alert_defn_local_sk');
    expect(errorDetails).toContain("Invalid Schema: alert.mk_alert_defn_localized_dm@1. extract time must be a int, long, timestamp, date");
  });

  it('should require a version', () => {
    const schema = noAnnotationSchema();
    delete schema.version;
    const actualError = edlSchemaService.validateSchemas([schema])
    const errorDetails = actualError.details.map(detail => detail.message);
    expect(errorDetails).toContain('\"version\" is required');
  })

  it('should allow a string version', () => {
    const schema = noAnnotationSchema();
    schema.version = '1';
    const result = edlSchemaService.validateSchemas([schema])
    expect(result).toEqual(null)
  })

  it('should not allow a version that is not a number or string', () => {
    const schema = noAnnotationSchema();
    schema.version = {id:1};
    const actualError = edlSchemaService.validateSchemas([schema])
    const errorDetails = actualError.details.map(detail => detail.message);
    expect(errorDetails).toContain('\"version\" must be a string');
  })

  it('should not allow a string version with multiple sequential periods', () => {
    const schema = noAnnotationSchema();
    schema.version = '1..0';
    const actualError = edlSchemaService.validateSchemas([schema])
    const errorDetails = actualError.details.map(detail => detail.message);
    expect(errorDetails).toContain("\"version\" with value \"1..0\" fails to match the number or semver #.#.# pattern");
  })

  it('should not allow a string version with characters', () => {
    const schema = noAnnotationSchema();
    schema.version = 'a.b.c';
    const actualError = edlSchemaService.validateSchemas([schema])
    const errorDetails = actualError.details.map(detail => detail.message);
    expect(errorDetails).toContain("\"version\" with value \"a.b.c\" fails to match the number or semver #.#.# pattern");

  })

  it('should not allow a string version with with to many repeating subversions', () => {
    const schema = noAnnotationSchema();
    schema.version = '1.2.3.4';
    const actualError = edlSchemaService.validateSchemas([schema])
    const errorDetails = actualError.details.map(detail => detail.message);
    expect(errorDetails).toContain("\"version\" with value \"1.2.3.4\" fails to match the number or semver #.#.# pattern");
  })

  it('should allow a version with semver format', () => {
    const schema = noAnnotationSchema();
    schema.version = '19876312.1234556677.122343498549835';
    const result = edlSchemaService.validateSchemas([schema])
    expect(result).toEqual(null)
  })

  it("should combine linked schemas with schemas for conversion", async () => {
    const dataset = {...jdCatalogDataset, schemas: []};
    const expectedIds = [dataset.linkedSchemas[0].id.split('--')[0] + '*'];

    apiHelper.getEDLMetadata.mockResolvedValue([]);
    const result = await edlSchemaService.convertSchemas(dataset);
    const schema = result[0];

    expect(apiHelper.getEDLMetadata).toHaveBeenCalledWith('', '', createExpectedEdlSchemaQuery(expectedIds));
    expect(schema.namespace).toEqual('com.deere.enterprise.datalake.raw');
    expect(schema.name).toEqual('channel_master_acct_address_data');
    expect(schema.version).toEqual('0.0.2');
  });

  it('should receive empty array when no schemas or linked schemas', async() => {
    const dataset = {...jdCatalogDataset, schemas: [], linkedSchemas: []};

    const result = await edlSchemaService.convertSchemas(dataset);

    expect(result).toEqual([])
  });

  it('Should use schema representation from EDL if JD Catalog Id exists for schema', async () => {
    //given
    const dataset = convertSchemasTestDataset;
    const expectedIds = [dataset.schemas[0].id.split('--')[0] + '*'];
    const edlCatalogId = dataset.schemas[0].id.split('--')[0] + '@1';
    const jdCatalogIdResponse = [{
      "name": "Test_Schema",
      "namespace": "com.deere.enterprise.datalake.enhance.core",
      "version": "0.0.1",
      jdCatalogId: edlCatalogId
    }];

    apiHelper.getEDLMetadata
        .mockResolvedValueOnce(jdCatalogIdResponse);
    //when && then
    const result = await edlSchemaService.convertSchemas(dataset);
    const schema = result[0];

    expect(apiHelper.getEDLMetadata).toHaveBeenCalledWith('','',createExpectedEdlSchemaQuery(expectedIds));
    expect(schema.namespace).toEqual('com.deere.enterprise.datalake.enhance.core');
    expect(schema.name).toEqual('Test_Schema');
    expect(schema.version).toEqual('0.0.1');
  });

  it('Should create schema representation if JD Catalog Id does not exist for schema', async () => {
    //given
    const dataset = convertSchemasTestDataset;
    const expectedIds = [dataset.schemas[0].id.split('--')[0] + '*'];

    const jdCatalogIdResponse = [];

    apiHelper.getEDLMetadata.mockResolvedValue(jdCatalogIdResponse);
    //when && then
    const result = await edlSchemaService.convertSchemas(dataset);
    const schema = result[0];

    expect(apiHelper.getEDLMetadata).toHaveBeenCalledWith('','',createExpectedEdlSchemaQuery(expectedIds));
    expect(schema.namespace).toEqual('com.deere.enterprise.datalake.raw');
    expect(schema.name).toEqual(dataset.schemas[0].name);
    expect(schema.version).toEqual(dataset.schemas[0].version);
  });

  it('Should throw error if created schema representation exists in EDL', () => {
    //given
    const dataset = convertSchemasTestDataset;

    const jdCatalogIdResponse = [];
    const representationResponse = [{
      "name": "testschema",
      "namespace": "com.deere.enterprise.datalake.raw",
      "version": "1.0.0"
    }];

    apiHelper.getEDLMetadata
      .mockResolvedValueOnce(jdCatalogIdResponse)
      .mockResolvedValueOnce(representationResponse);
    
    //when && then
    return expect(edlSchemaService.convertSchemas(dataset)).rejects.toEqual(new Error(`Schema name (${dataset.schemas[0].name}) and version (${dataset.schemas[0].version}) are not unique in EDL change the name and/or version`))
  });

  it('Should throw error if duplicate JD Catalog IDs exists for schema', async () => {
    //given
    const dataset = convertSchemasTestDataset;
    const edlCatalogId = dataset.schemas[0].id.split('--')[0];
    const duplicateId1 = edlCatalogId+'@1';
    const duplicateId2 = edlCatalogId+'@2';
    const jdCatalogIdResponse = [
      {
        "jdCatalogId": duplicateId1
      },
      {
        "jdCatalogId": duplicateId2
      }
    ];

    apiHelper.getEDLMetadata.mockResolvedValue(jdCatalogIdResponse);
    //when && then

    return expect(edlSchemaService.convertSchemas(dataset)).rejects.toEqual(new Error(`Duplicate IDs found in EDL for Schema name (${dataset.schemas[0].name}) version (${dataset.schemas[0].version})`))
  });

  const convertSchemasTestDataset = {
    ...jdCatalogDataset, 
    schemas: jdCatalogDataset.schemas.splice(1), 
    linkedSchemas: []
  }
});
