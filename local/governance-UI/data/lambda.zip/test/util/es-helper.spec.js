const conf = require("../../lib/conf.js");
const elasticsearch = require('elasticsearch');
const awses = require('http-aws-es');
const esHelper = require('../../lib/util/es-helper');

jest.mock("elasticsearch");
jest.mock('http-aws-es');
jest.mock("../../lib/conf");

const config = {
    catalogESUrl: 'https://search-edl-data-catalog-3zq55guoniroi7uvyb5jq3zvaq.us-east-1.es.amazonaws.com/'
  };

describe("Elasticsearch tests", () => {

    let searchFn =  jest.fn().mockResolvedValue({
        hits: {
          hits: [
            {
                _id: 1234567890,  
                _source: {
                  name: 'fakeschema',
                  namespace: 'com.deere.enterprise.datalake.enhance',
                  jdCatalogId: '123e0a9b-ec10-479e-ad42-af51eb013282@2'
              }
            },
            {
                _id: 2345678901,  
                _source: {
                  name: 'anotherfakeschema',
                  namespace: 'com.deere.enterprise.datalake.enhance',
                  jdCatalogId: '231e0a9b-ec10-479e-ad42-af51eb013282@2'
              }
            },
          ]
        }
      });
    let deleteFn = jest.fn().mockResolvedValue([]);

    beforeEach(async () => {
        jest.spyOn(conf, 'getEnv').mockReturnValue('devl');
        conf.getConfig.mockResolvedValue(config);

        elasticsearch.Client.mockImplementation(() => ({
            search: searchFn,
            delete: deleteFn
        }));
    });

    it('Should delete given missing schemas from elastic search', async() => {
        //given
        const missingSchemas = [{"jdCatalogId": "123e0a9b-ec10-479e-ad42-af51eb013282"}];
        //when
        await esHelper.findAndDeleteNonDeletedSchemas(missingSchemas);
        //then
        expect(searchFn).toBeCalledWith({
            index: 'schemas3',
            type: 'schema',
            body: {
                query: {
                    match: {
                        "jdCatalogId": "123e0a9b-ec10-479e-ad42-af51eb013282"
                    }
                }    
            }
        });
        expect(deleteFn).toBeCalledTimes(1);
    });

    it('Should not call delete if missing schemas are not found in search', async() => {
        //given
        const missingSchemas = [
            {"jdCatalogId": "123e0a9b-ec10-479e-ad42-af51eb013282"},
            {"jdCatalogId": "231e0a9b-ec10-479e-ad42-af51eb013282"},
            {"jdCatalogId": "312e0a9b-ec10-479e-ad42-af51eb013282"}
        ];
        const searchFn1 = jest.fn().mockResolvedValue([]);
        elasticsearch.Client.mockImplementation(() => ({
            search: searchFn1,
            delete: deleteFn
        }));
        //when
        await esHelper.findAndDeleteNonDeletedSchemas(missingSchemas);
        //then
        expect(searchFn1).toBeCalledTimes(3);
        expect(deleteFn).toBeCalledTimes(0);
    });

    it('Should throw exception if fail to delete missing schemas', async() => {
        //given
        const missingSchemas = [
            {"jdCatalogId": "123e0a9b-ec10-479e-ad42-af51eb013282"}
        ];
        elasticsearch.Client.mockImplementation(() => ({
            search: searchFn,
            delete: jest.fn().mockRejectedValue('Boom')
        }));
        //when
        try {
            await esHelper.findAndDeleteNonDeletedSchemas(missingSchemas);
            expect(true).toEqual(false);
        } catch(err) {
            //then
            expect(err).toEqual('Failed to delete schema for the schema id: 123e0a9b-ec10-479e-ad42-af51eb013282');
        }
    });

    it('Shoud throw exception if unable to get the ES Client', async() => {
        //given
        const missingSchemas = [
            {"jdCatalogId": "123e0a9b-ec10-479e-ad42-af51eb013282"}
        ];
        elasticsearch.Client.mockRejectedValue('Failed to get ES Client');
        //when
        try {
            await esHelper.findAndDeleteNonDeletedSchemas(missingSchemas);
            expect(true).toEqual(false);
        } catch(err) {
            //then
            expect(err).toEqual('Failed to get ES Client');
        }
    });
});